function logger(...text) {
  if (process.env.REACT_APP_SITE_ENVIRONMENT === 'DEV') {
    console.log(...text);
  }
}
export function errorLogger(...text) {
  if (process.env.REACT_APP_SITE_ENVIRONMENT === 'DEV') {
    console.error(...text);
  }
}
export function warnLogger(...text) {
  if (process.env.REACT_APP_SITE_ENVIRONMENT === 'DEV') {
    console.warn(...text);
  }
}

export default logger;
