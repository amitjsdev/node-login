import {
  GET_STORE_LIST
} from '../actions/ActionTypes';
import appLogger from '../../logger';
import {composeResetReducer} from './reset';

const defaultStoreState = {
  list: null,
  current: {}
};
const storeReducer = (state = defaultStoreState, action) => {
  // if (action.type === GET_STORE_LIST.REQUEST) {
  //   return {...defaultStoreState};
  // }
  if (action.type === GET_STORE_LIST.SUCCESS) {
    const { response } = action.payload;
    return {
      list: response,
      current: response && response.length > 0 ? response[0]: {}
    }
  }
  return state;
};

export default composeResetReducer(storeReducer, defaultStoreState);
