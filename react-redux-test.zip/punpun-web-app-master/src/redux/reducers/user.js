import {
  SET_USER
} from '../actions/ActionTypes';
import appLogger from '../../logger';
import {composeResetReducer} from './reset';

const defaultUserState = {
  user: {},
};
const userReducer = (state = defaultUserState, action) => {
  if (action.type === SET_USER) {
    if (action.payload && action.payload.params) {
      const data = {...action.payload.params};
      return {
        ...state,
        user: data
      };
    }
  }
  return state;
};

export default composeResetReducer(userReducer, defaultUserState);
