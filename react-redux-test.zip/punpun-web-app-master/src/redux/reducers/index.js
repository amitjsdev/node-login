import MenuReducer from './menu';
import OrderReducer from './order';
import StoreReducer from './store';
import UserReducer from './user';
import { combineReducers } from 'redux';
const RootReducer = combineReducers({
  menu: MenuReducer,
  order: OrderReducer,
  user: UserReducer,
  store: StoreReducer,
});

export default RootReducer;
