import {
  COMPLETE_ORDER,
  DELETE_CURRENT_ITEM,
  DELETE_ORDER,
  PUNCH_CURRENT_ORDER,
  PUNCH_ITEM,
  UPDATE_ORDER,
} from '../actions/ActionTypes';

import appLogger from '../../logger';
import {composeResetReducer} from './reset';

const defaultOrderState = {
  pendingOrders: [],
  currentOrder: {items: []},
};
const orderReducer = (state = defaultOrderState, action) => {
  if (action.type === PUNCH_ITEM) {
    if (action.payload && action.payload.params) {
      const data = {...action.payload.params};
      const item = {
        Name: data.Name,
        Price: data.Price,
        quantity: isNaN(data.quantity) ? 0 : Number(data.quantity),
      };
      const oldState = {...state};
      const updatedOrderItems = {...oldState.currentOrder}.items || [];
      const index = updatedOrderItems.findIndex((i) => i.Name === item.Name);
      if (index >= 0) {
        const alreadyItem = updatedOrderItems[index];
        if (!item.quantity) {
          item.quantity = (alreadyItem.quantity || 1) + 1;
        }
        updatedOrderItems.splice(index, 1, item);
      } else {
        if (!item.quantity) {
          item.quantity = 1;
        }
        updatedOrderItems.push(item);
      }
      return {
        ...state,
        currentOrder: {...oldState.currentOrder, items: updatedOrderItems},
      };
    }
  }

  if (action.type === DELETE_CURRENT_ITEM) {
    if (action.payload && action.payload.params) {
      const data = {...action.payload.params};
      const oldState = {...state};
      const updatedOrderItems = {...oldState.currentOrder}.items;
      const index = updatedOrderItems.findIndex((i) => i.Name === data.Name);
      if (index >= 0) {
        updatedOrderItems.splice(index, 1);
      }
      let updatedCurrentOrder = {
        ...oldState.currentOrder,
        items: updatedOrderItems,
      };
      if (updatedOrderItems.length === 0) {
        updatedCurrentOrder = {items: []};
      }
      return {
        ...state,
        currentOrder: updatedCurrentOrder,
      };
    }
  }

  if (action.type === PUNCH_CURRENT_ORDER.SUCCESS) {
    const oldState = {...state};
    const {response} = action.payload;
    if (response) {
      const index = oldState.pendingOrders.findIndex(
        (i) => i.id === response.id
      );
      let updatedArray = [...oldState.pendingOrders];
      if (index >= 0) {
        updatedArray.splice(index, 1, response);
      } else {
        updatedArray = [...oldState.pendingOrders, response];
      }
      return {
        ...state,
        currentOrder: {items: []},
        pendingOrders: updatedArray,
      };
    }
  }
  if (action.type === COMPLETE_ORDER.SUCCESS) {
    const oldState = {...state};
    const {response} = action.payload;
    if (response) {
      return {
        ...state,
        currentOrder: {items: []},
        pendingOrders: oldState.pendingOrders.filter(
          (i) => i.id !== response.id
        ),
      };
    }
  }
  if (action.type === DELETE_ORDER.SUCCESS) {
    const oldState = {...state};
    const {response} = action.payload;
    if (response) {
      return {
        ...state,
        pendingOrders: oldState.pendingOrders.filter(
          (i) => i.id !== response.id
        ),
      };
    }
  }
  if (action.type === UPDATE_ORDER.SUCCESS) {
    const oldState = {...state};
    const {response} = action.payload;
    if (response) {
      const index = oldState.pendingOrders.findIndex(
        (i) => i.id === response.id
      );
      if (index >= 0) {
        return {
          ...state,
          currentOrder: oldState.pendingOrders[index],
        };
      }
    }
  }
  return state;
};

export default composeResetReducer(orderReducer, defaultOrderState);
