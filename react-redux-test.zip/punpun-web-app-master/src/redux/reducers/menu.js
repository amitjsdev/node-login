import {
  GET_MENU
} from "../actions/ActionTypes";
import appLogger from "../../logger";
import { composeResetReducer } from "./reset";

const defaultMenuState = {
  items: []
};
const menuReducer = (state = defaultMenuState, action) => {
  // if (action.type === GET_MENU.REQUEST) {
  //   return {
  //     ...state,
  //     items: []
  //   };
  // }

  if (action.type === GET_MENU.SUCCESS) {
    const { response } = action.payload;
    return {
      ...state,
      items: response
    };
  }

  return state;
};

export default composeResetReducer(menuReducer, defaultMenuState);
