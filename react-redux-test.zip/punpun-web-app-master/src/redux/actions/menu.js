import { GET_MENU } from "./ActionTypes";

export const getMenuRequest = params => ({
  payload: { params },
  type: GET_MENU.REQUEST
});

export const getMenuSuccess = response => ({
  payload: { response },
  type: GET_MENU.SUCCESS
});

export const getMenuFailed = error => ({
  payload: { error },
  type: GET_MENU.FAILED
});