import { ADD_STORE, GET_STORE_LIST } from "./ActionTypes";

export const getStoreListRequest = params => ({
  payload: { params },
  type: GET_STORE_LIST.REQUEST
});

export const getStoreListSuccess = response => ({
  payload: { response },
  type: GET_STORE_LIST.SUCCESS
});

export const getStoreListFailed = error => ({
  payload: { error },
  type: GET_STORE_LIST.FAILED
});


export const addStoreRequest = params => ({
  payload: { params },
  type: ADD_STORE.REQUEST
});

export const addStoreSuccess = response => ({
  payload: { response },
  type: ADD_STORE.SUCCESS
});

export const addStoreFailed = error => ({
  payload: { error },
  type: ADD_STORE.FAILED
});
