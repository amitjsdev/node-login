
const generateActionTypes = action => ({
  SUCCESS: `${action}_SUCCESS`,
  FAILED: `${action}_FAILED`,
  REQUEST: `${action}_REQUEST`,
  STATUS: `${action}_STATUS`
});

// Global ActionTypes
export const RESET = "GLOBAL/RESET";


// MENU
export const GET_MENU = generateActionTypes(
  "MENU/GET"
);

// ORDER
export const PUNCH_ITEM = "ITEM/PUNCH";
export const DELETE_CURRENT_ITEM = generateActionTypes("CURRENT_ORDER_ITEM/DELETE");
export const PUNCH_CURRENT_ORDER = generateActionTypes("CURRENT_ORDER/PUNCH");
export const COMPLETE_ORDER = generateActionTypes("ORDER/COMPLETE");
export const DELETE_ORDER = generateActionTypes("ORDER/DELETE");
export const UPDATE_ORDER = generateActionTypes("ORDER/UPDATE");

export const LOCAL_CART_ADD_ITEM="LOCAL_CART_ADD_ITEM";
export const LOCAL_CART_REMOVE_ITEM="LOCAL_CART_REMOVE_ITEM";
export const CLEAR_CART_ITEM='CLEAR_CART_ITEM';
export const ADD_ORDER_TO_PENDING_LIST='ADD_ORDER_TO_PENDING_LIST';
export const REMOVE_ORDER_FROM_LIST='REMOVE_ORDER_FROM_LIST';
export const EDIT_PENDING_ORDER_ITEM='EDIT_PENDING_ORDER_ITEM';
export const LINK_CUSTOMER_TO_ORDER='LINK_CUSTOMER_TO_ORDER';




// User
export const SET_USER = "USER/SET";

// Stores
export const GET_STORE_LIST = generateActionTypes("STORE/GET_LIST");
export const ADD_STORE = generateActionTypes("STORE/ADD");