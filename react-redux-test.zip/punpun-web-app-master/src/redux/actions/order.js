import { COMPLETE_ORDER, DELETE_CURRENT_ITEM, DELETE_ORDER, PUNCH_CURRENT_ORDER, PUNCH_ITEM, UPDATE_ORDER } from "./ActionTypes";

export const punchItem = params => ({
  payload: { params },
  type: PUNCH_ITEM
});


export const deleteCurrentItem = params => ({
  payload: { params },
  type: DELETE_CURRENT_ITEM
});



export const punchCurrentOrderRequest = params => ({
  payload: { params },
  type: PUNCH_CURRENT_ORDER.REQUEST
});

export const punchCurrentOrderSuccess = response => ({
  payload: { response },
  type: PUNCH_CURRENT_ORDER.SUCCESS
});

export const punchCurrentOrderFailed = error => ({
  payload: { error },
  type: PUNCH_CURRENT_ORDER.FAILED
});


export const completeOrderRequest = params => ({
  payload: { params },
  type: COMPLETE_ORDER.REQUEST
});

export const completeOrderSuccess = response => ({
  payload: { response },
  type: COMPLETE_ORDER.SUCCESS
});

export const completeOrderFailed = error => ({
  payload: { error },
  type: COMPLETE_ORDER.FAILED
});


export const deleteOrderRequest = params => ({
  payload: { params },
  type: DELETE_ORDER.REQUEST
});

export const deleteOrderSuccess = response => ({
  payload: { response },
  type: DELETE_ORDER.SUCCESS
});

export const deleteOrderFailed = error => ({
  payload: { error },
  type: DELETE_ORDER.FAILED
});


export const updateOrderRequest = params => ({
  payload: { params },
  type: UPDATE_ORDER.REQUEST
});

export const updateOrderSuccess = response => ({
  payload: { response },
  type: UPDATE_ORDER.SUCCESS
});

export const updateOrderFailed = error => ({
  payload: { error },
  type: UPDATE_ORDER.FAILED
});