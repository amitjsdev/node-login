import { RESET } from './ActionTypes';

export * from './menu';
export * from './user';
export * from './store';

export const resetReducer = (params) => ({
	payload: { params },
	type: RESET,
});

