import { SET_USER } from "./ActionTypes";

export const setUserRequest = params => ({
  payload: { params },
  type: SET_USER
});
