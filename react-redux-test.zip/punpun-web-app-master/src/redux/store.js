import { applyMiddleware, compose, createStore } from "redux";
import { persistReducer, persistStore } from "redux-persist";

import RootReducer from "./reducers";
import RootSaga from "./sagas";
import appMiddleware from "./middlewares";
import createSagaMiddleware from "redux-saga";
import storage from "redux-persist/lib/storage";

/*
 * Configuration for persistence store
 */
const persistConfig = {
  blacklist: ["store", "menu", "user"],
  debug: false,
  key: "root",
  keyPrefix: "v.1",
  storage,
  whitelist: ["order"]
};

const enhancers = [];
if (process.env.NODE_ENV === "development") {
  const devToolsExtension = window.devToolsExtension;

  if (typeof devToolsExtension === "function") {
    enhancers.push(devToolsExtension());
  }
}

const sagaMiddleware = createSagaMiddleware();
const middlewares = [...appMiddleware, sagaMiddleware];
const persistedReducer = persistReducer(persistConfig, RootReducer);

function configureStore() {
  const store = createStore(
    persistedReducer,
    compose(applyMiddleware(...middlewares), ...enhancers)
  );

  return store;
}

const store = configureStore();
persistStore(store, null, () => {
  // console.tron.display({name: 'rehydrated state', value: store.getState()});
});

sagaMiddleware.run(RootSaga);

export default store;
