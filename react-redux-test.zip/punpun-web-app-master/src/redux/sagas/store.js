import {ADD_STORE, GET_STORE_LIST} from '../actions/ActionTypes';
import {all, call, fork, put, select, takeLatest} from 'redux-saga/effects';
import {getStoreListRequest, getStoreListSuccess} from '../actions';

import {URLS} from '../../service/url';
import appLogger from '../../logger';
import axios from 'axios';

export function* watchStoreSaga() {
  yield all([fork(watchGetStoreList), fork(watchAddStore)]);
}

function* watchGetStoreList() {
  yield takeLatest(GET_STORE_LIST.REQUEST, getStoreListSaga);
}

function* watchAddStore() {
  yield takeLatest(ADD_STORE.REQUEST, addStoreSaga);
}

function* addStoreSaga({payload}) {
  const {resolve, reject, ...data} = payload.params || {};
  try {
    const {user} = yield select((state) => ({
      user: state.user.user,
    }));
    const result = yield call(axios.post, URLS.ADD_STORE, {
      email: user.email,
      name: user.name,
      store_name: data.storeName,
      address: data.storeAddress,
      gst: data.gst,
    });
    console.log('addStore: ', result);
    if (result && result.data && result.data.statusCode === 200) {
      yield put(getStoreListRequest());
      if (resolve) {
        resolve(result.data);
      }
      return;
    }
    if (reject) reject('Error in add store');
  } catch (error) {
    console.log('addStore error: ', error);
    if (reject) reject(error);
  }
}

function* getStoreListSaga({payload}) {
  const {resolve, reject} = payload.params || {};
  try {
    const {user} = yield select((state) => ({
      user: state.user.user,
    }));
    const result = yield call(axios.post, URLS.GET_STORE_LIST, {
      email: user.email,
    });
    console.log('getStoreListSaga: ', result);
    if (result && result.data && result.data.statusCode === 200) {
      const stores = JSON.parse(result.data.body);
      yield put(getStoreListSuccess(stores));
      if (resolve) {
        resolve(stores);
      }
      return;
    }
    if (reject) reject('Store Not Available');
  } catch (error) {
    console.log('getStoreListSaga error: ', error);
    if (reject) reject(error);
  }
}
