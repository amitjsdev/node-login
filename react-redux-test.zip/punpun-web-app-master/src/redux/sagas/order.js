import {
  COMPLETE_ORDER,
  DELETE_ORDER,
  PUNCH_CURRENT_ORDER,
  UPDATE_ORDER
} from "../actions/ActionTypes";
import { all, call, fork, put, select, takeEvery } from "redux-saga/effects";
import {
  completeOrder,
  updatePendingOrder
} from "../../service/functions/order";
import { completeOrderSuccess, deleteOrderSuccess, punchCurrentOrderSuccess, updateOrderSuccess } from "../actions/order";

import appLogger from "../../logger";

export function* watchOrderSaga() {
  yield all([
    fork(watchPunchPendingOrder),
    fork(watchCompleteOrder),
    fork(watchDeleteOrder),
    fork(watchUpdateOrder)
  ]);
}

function* watchPunchPendingOrder() {
  yield takeEvery(PUNCH_CURRENT_ORDER.REQUEST, punchCurrentPendingOrder);
}

function* watchCompleteOrder() {
  yield takeEvery(COMPLETE_ORDER.REQUEST, completeOrderSaga);
}


function* watchDeleteOrder() {
  yield takeEvery(DELETE_ORDER.REQUEST, deleteOrderSaga);
}


function* watchUpdateOrder() {
  yield takeEvery(UPDATE_ORDER.REQUEST, updateOrderSaga);
}

function* punchCurrentPendingOrder({ payload }) {
  const { resolve, reject } = payload.params || {};
  try {
    const { currentOrder } = yield select(state => ({
      currentOrder: state.order.currentOrder
    }));
    const date = new Date();
    const items = currentOrder.items;
    let totalAmount = 0;
    items.forEach(i => {
      totalAmount += Number(i.Price) * Number(i.quantity);
    })
    const order = {
      items:[...currentOrder.items],
      id: currentOrder.id || date.getTime(),
      time: currentOrder.time || date.toLocaleString(),
      totalAmount
    }
    yield put(punchCurrentOrderSuccess(order));
    const { pendingOrders } = yield select(state => ({
      pendingOrders: state.order.pendingOrders,
    }));
    const result = yield call(updatePendingOrder, pendingOrders);
    if (resolve)
      resolve(result);
  } catch (error) {
     console.log("punchCurrentPendingOrder error", error);
    if (reject)
      reject(error);
  }
}



function* completeOrderSaga({ payload }) {
  const { resolve, reject, ...order } = payload.params || {};
  try {
    console.log("compelteorder saga: ", order)
    yield put(completeOrderSuccess(order));
    const result = yield call(completeOrder, order);
    const { pendingOrders } = yield select(state => ({
      pendingOrders: state.order.pendingOrders,
    }));
    yield call(updatePendingOrder, pendingOrders);
    if (resolve)
      resolve("success");
  } catch (error) {
     console.log("compelteorder error", error);
    if (reject)
      reject(error);
  }
}


function* deleteOrderSaga({ payload }) {
  const { resolve, reject, ...order } = payload.params || {};
  try {
    console.log("deleteOrderSaga saga: ", order)
    yield put(deleteOrderSuccess(order));
    const { pendingOrders } = yield select(state => ({
      pendingOrders: state.order.pendingOrders,
    }));
    const result = yield call(updatePendingOrder, pendingOrders);
    if (resolve)
      resolve("success");
  } catch (error) {
     console.log("deleteOrderSaga error", error);
    if (reject)
      reject(error);
  }
}



function* updateOrderSaga({ payload }) {
  const { resolve, reject, ...order } = payload.params || {};
  try {
    console.log("updateOrderSaga saga: ", order)
    yield put(updateOrderSuccess(order));
    // const { pendingOrders } = yield select(state => ({
    //   pendingOrders: state.order.pendingOrders,
    // }));
    // yield call(updatePendingOrder, pendingOrders);
    if (resolve)
      resolve("success");
  } catch (error) {
     console.log("updateOrderSaga error", error);
    if (reject)
      reject(error);
  }
}

