import { all, call, fork, put, select, takeLatest } from "redux-saga/effects";

import {
  GET_MENU
} from "../actions/ActionTypes";
import appLogger from "../../logger";
import { getMenuSuccess } from "../actions";
import {
  setupMenuFile
} from "../../service/google/drive";

export function* watchMenuSaga() {
  yield all([
    fork(watchGetMenu)
  ]);
}

function* watchGetMenu() {
  yield takeLatest(GET_MENU.REQUEST, getMenuSaga);
}

function* getMenuSaga({ payload }) {
  const { resolve, reject } = payload.params || {};
  try {
    const result = yield call(setupMenuFile);
    yield put(getMenuSuccess(result));
    if (resolve)
      resolve(result);
  } catch (error) {
    console.log("Menu error: ", error);
    if (reject)
      reject(error);
  }
}
