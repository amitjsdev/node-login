import { fork } from "redux-saga/effects";
import { watchMenuSaga } from "./menu";
import { watchOrderSaga } from "./order";
import { watchStoreSaga } from "./store";

export default function* rootSagas() {
  yield fork(watchMenuSaga);
  yield fork(watchOrderSaga);
  yield fork(watchStoreSaga)
}
