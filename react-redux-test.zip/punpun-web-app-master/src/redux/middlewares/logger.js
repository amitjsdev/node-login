import appLogger from "../../logger";
const ENABLE_LOG = true;

const logger = store => next => action => {
  const result = next(action);
  if (ENABLE_LOG) {
    appLogger({
      action,
      state: store.getState()
    });
  }
  return result;
};

export default logger;
