import logger from './logger';

export default [
  logger
];
