import React, {useContext, useEffect, useState} from 'react';
import { Redirect, Route } from 'react-router-dom';

import { UserContext } from './providers/userProvider';

const PrivateRoutes = ({ component: Component, type, ...rest }) => {
  const {user, menuData, storeList} = useContext(UserContext);
  const [redirect, setredirect] = useState("loading");

  useEffect(() => {
    if (user !== undefined) {
      if (user === null) {
        setredirect("/");
      } else {
        setredirect("");
      }
    }
  }, [user]);

  console.log("menu data: ", menuData)

  if (redirect === "loading" || (user && (!menuData && !storeList))) {
    return null;
  }

  if (redirect && redirect !== "loading") {
    return <Redirect to={redirect} />;
  }

  if (type !== "setup" && rest.path !== "/addStore" && storeList && storeList.length === 0) {
    return <Redirect to={"/addStore"} />;
  }

  
  if (type !== "setup" && menuData && (!menuData.folderId || !menuData.menuFileId)) {
    return <Redirect to={"/uploadMenu"} />;
  }

  // if (type === "setup" && menuData &&  (menuData.folderId && menuData.menuFileId)) {
  //   return <Redirect to={"/dashboard"} />;
  // }

  return (
  <Route
    {...rest}
    render={props =>
      <Component {...props} />
    }
  />
)};

export default PrivateRoutes;
