import './App.css';

import Login from './pages/login';
import { Provider } from 'react-redux';
import Routes from './pages/routes';
import logo from './logo.svg';
import store from './redux/store';
import { useEffect } from 'react';
import { SnackbarProvider } from 'notistack';

function App() {
  return (
    <Provider store={store}>
      <SnackbarProvider maxSnack={3}>

    <div className="App">
      <Routes />
    </div>
    </SnackbarProvider>

    </Provider>
  );
}

export default App;
