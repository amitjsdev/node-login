import RSC from "react-scrollbars-custom";

const ScrollBarHoc = (props) => (
    <RSC  style={{width:'100%',height: `${props.height}px` }}>
            {props.children}
    </RSC>
        );

export default ScrollBarHoc;