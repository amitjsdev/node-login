const MenuImageLayout = (props) => (
    <div className="card login-form mx-auto d-flex align-items-center justify-content-center" style={{width:"450px"}}>
	<div className="card-body">
		<div className="card-text">
            {props.children}
            </div>
</div>
</div>);

export default MenuImageLayout;