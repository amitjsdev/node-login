import {
  Link,
  Redirect,
  Route,
  Switch,
  useHistory,
  useLocation,
} from 'react-router-dom';
import React, {lazy, useState} from 'react';

import Cart from '../pages/dashboard/components/cart';
import Checkout from '../pages/dashboard/components/checkout';
import CustomModal from './CustomModal';
import DashboardOutlinedIcon from '@material-ui/icons/DashboardOutlined';
import { ExitToApp } from '@material-ui/icons';
import InsertChartIcon from '@material-ui/icons/InsertChart';
import PendingOrders from '../pages/dashboard/components/pendingOrders';
import ScrollBarHoc from './ScrollBarHoc';
import SettingsIcon from '@material-ui/icons/Settings';
import ShowChartIcon from '@material-ui/icons/ShowChart';
import StoreRoundedIcon from '@material-ui/icons/StoreRounded';
import {connect} from 'react-redux';
import {resetReducer} from '../redux/actions';
import {signOut} from '../service/google';

export const ModalContext = React.createContext({});

const Layout = (props) => {
  const [open, setOpen] = React.useState(false);
  const [actionType, setActionType] = React.useState(1);
  const [order, setOrder] = React.useState(null);

  const handleOpen = (type, order) => {
    console.log('handleOpen', type, order);
    handleActionType(type, order);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleActionType = (type, order) => {
    console.log('handleActionType', type, order);
    setActionType(type);
    setOrder(order);
  };
  const handleSignOut = () => {
    props.reset();
    signOut();
  };

  let history = useHistory();

  const location = useLocation();
  return (
    <ModalContext.Provider
      value={{
        handleClose: handleClose,
        handleOpen: handleOpen,
        handleActionType: handleActionType,
      }}
    >
      <>
        <div className="main" id="main">
          <div className="d-flex" id="wrapper">
            <div className="bg-light border-right" id="sidebar-wrapper">
              <div className="sidebar-heading pb-4">
                <h1>
                  <StoreRoundedIcon className="mr-3" />
                  {/* {userInfo.restaurant_name} */}
                  {props.currentStore?.store_name}
                </h1>
                {/* <p style={{fontSize: 12}}>GST: {props.currentStore?.gst}</p> */}
              </div>
              <div className="list-group list-group-flush">
                <ul>
                  <li>
                    <Link
                      to="/dashboard"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <DashboardOutlinedIcon /> POS
                    </Link>
                  </li>
                  <li className="nav-item active">
                    <Link
                      to="/analytics"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <InsertChartIcon /> Analytics
                    </Link>
                  </li>
                  <li className="nav-item active">
                    <Link
                      to="/settings"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <SettingsIcon /> Settings
                    </Link>
                  </li>
                  {/* <li> */}
                  {/* <Link to="/stock" className="list-group-item list-group-item-action bg-light" >
        <ShowChartIcon /> Stock
        </Link>
            </li> */}
                  {/* <li><Link to="/setting" className="list-group-item list-group-item-action bg-light"><SettingsIcon /> Setting</Link></li> */}
                  <li>
                    <span
                      style={{cursor: 'pointer'}}
                      className="list-group-item list-group-item-action bg-light"
                      onClick={handleSignOut}
                    >
                      <ExitToApp /> Sign Out
                    </span>
                  </li>
                </ul>
              </div>
              <img src="images/logo-bottom.jpg" className="sidebar-image" />
            </div>

            <div id="page-content-wrapper">
              <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                <button
                  className="navbar-toggler"
                  id="menu-toggle"
                  type="button"
                  data-toggle="collapse"
                  data-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span className="navbar-toggler-icon"></span>
                </button>

                <ul className="navbar-nav ml-auto mt-2 mt-lg-0">
                  <li className="nav-item active">
                    <Link
                      to="/dashboard"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <DashboardOutlinedIcon /> POS
                    </Link>
                  </li>
                  <li className="nav-item ">
                    <Link
                      to="/analytics"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <InsertChartIcon /> Analytics
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      to="/stock"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <ShowChartIcon /> Stock
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link
                      to="/setting"
                      className="list-group-item list-group-item-action bg-light"
                    >
                      <SettingsIcon /> Setting
                    </Link>
                  </li>
                </ul>
              </nav>

              <div className="container-fluid">
                <div className="row">
                  <div className="col-md-8">{props.children}</div>
                  <div className="col-md-4 border-left-dark">
                    <h2 className="pending mt-4">Pending</h2>
                    <ScrollBarHoc height={window.screen.height - 200}>
                      <PendingOrders />
                    </ScrollBarHoc>
                    {/* sdfsdffds{JSON.stringify(pendingOrders)} */}
                    {/* {pendingOrders.map((element,index)=><PendingOrders key={index} order={element} arrayIndex={index} />)}  */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <CustomModal
          open={open}
          handleClose={handleClose}
          title="Hello"
          description="drewdsfasdf"
        >
          {order && (
            <>
              {actionType == 1 ? (
                <Cart items={order.items} order={order} />
              ) : (
                <Checkout items={order.items} order={order} />
              )}
            </>
          )}
        </CustomModal>
      </>
    </ModalContext.Provider>
  );
};
const selector = (state) => {
  return {
    currentStore: state.store.current,
    currentOrder: state.order.currentOrder,
  };
};

const actions = (dispatch) => ({
  reset: () => dispatch(resetReducer()),
});

export default connect(selector, actions)(Layout);
