import React from 'react';
import { Modal } from '@material-ui/core';

export default function CustomModal(props) {
  

 const {handleClose,open,title,description}=props;
  return (<>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby={title}
        aria-describedby={description}
      >
       {props.children}
      </Modal>
      </>
  );
}