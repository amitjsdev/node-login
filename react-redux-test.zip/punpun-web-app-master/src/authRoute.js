import React, {useContext, useEffect, useState} from 'react';
import { Redirect, Route } from 'react-router-dom';

import { UserContext } from './providers/userProvider';

const AuthRoutes = ({ component: Component, ...rest }) => {
  const {user, menuData} = useContext(UserContext);
  const [redirect, setredirect] = useState("loading");

  useEffect(() => {
    if (user !== undefined) {
      if (user === null) {
        setredirect("");
      } else {
        setredirect("/dashboard");
      }
    }
  }, [user]);

  if (redirect === "loading") {
    return null;
  }

  if (redirect && redirect !== "loading") {
    return <Redirect to={redirect} />;
  }


  return (
  <Route
    {...rest}
    render={props =>
      <Component {...props} />
    }
  />
)};

export default AuthRoutes;
