import { getGoogleFile, getMainFolderId } from '../google/drive'
export const getFolderId = () => {
  return getMainFolderId();
}

export const getFile = (data) => {
  return getGoogleFile(data)
}