import { clearSheet, createSheet, updateSheet } from "../google/sheet";
import { createOrFindMainFolder, listPunPunFiles } from "../google/drive";

export const createMenuFile = (menu) => {
  return new Promise(async (resolve, reject) => {
    try {
      const folder = await createOrFindMainFolder();
      const menuSheet = await createSheet("Menu", folder);
      await clearSheet(menuSheet.id)
      const result = await updateSheet(menuSheet.id, menu);
      await listPunPunFiles()
      resolve(result);
    } catch(ex) {
      reject(ex);
    }
  })
}