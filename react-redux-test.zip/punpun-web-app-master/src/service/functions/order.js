import {
  addSheet,
  appendRowInSheet,
  checkIsSheetExist,
  clearSheet,
  createSheet,
  getSheetData,
  updateSheet,
} from '../google/sheet';
import {getFile, getFolderId} from '.';

import {listPunPunFiles} from '../google/drive';

const PENDING_ORDER_TITLES = [
  'Id',
  'Time',
  'Customer Name',
  'Customer Phone',
  'Total Amount',
  'GST',
  'Items',
  'Discount',
  'Payment Mode',
];

const PENDING_ORDER_FILE_NAME = 'Pending Order';
const ORDER_FILE_NAME = 'Order';

export const createOrFindFile = (fileName, titleRow, sheetName = 'Sheet1') => {
  return new Promise(async (resolve, reject) => {
    try {
      let file = getFile({
        fileName: fileName,
        mimeType: 'application/vnd.google-apps.spreadsheet',
      });
      if (!file) {
        file = await createSheet(fileName, getFolderId());
        await updateSheet(file.id, [titleRow], sheetName);
        listPunPunFiles();
      }
      resolve(file);
    } catch (ex) {
      reject(ex);
    }
  });
};

const getFormattedOrder = (order) => {
  const keys = [
    'id',
    'time',
    'customerName',
    'customerPhone',
    'totalAmount',
    'gst',
    'items',
    'discount',
    'paymentMode',
  ];
  const row = [];
  keys.forEach((key) => {
    row.push(JSON.stringify(order[key]) || '');
  });
  return row;
};

export const addPendingOrder = (order) => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('Order: ', order);
      const file = await createOrFindFile(
        PENDING_ORDER_FILE_NAME,
        PENDING_ORDER_TITLES
      );
      const result = await appendRowInSheet(file.id, [
        getFormattedOrder(order),
      ]);
      resolve(file);
    } catch (ex) {
      reject(ex);
    }
  });
};

const getPendingOrderList = (orders) => {
  const formattedOrders = orders.map((order) => getFormattedOrder(order));
  return [PENDING_ORDER_TITLES, ...formattedOrders];
};

export const updatePendingOrder = (orders) => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('Orders: ', orders);
      const file = await createOrFindFile(
        PENDING_ORDER_FILE_NAME,
        PENDING_ORDER_TITLES
      );
      const formattedOrders = getPendingOrderList(orders);
      await clearSheet(file.id);
      const result = await updateSheet(file.id, formattedOrders);
      resolve(file);
    } catch (ex) {
      reject(ex);
    }
  });
};

export const completeOrder = (order) => {
  return new Promise(async (resolve, reject) => {
    try {
      const file = await createOrFindFile(
        ORDER_FILE_NAME,
        PENDING_ORDER_TITLES
      );
      const date = new Date();
      const sheetName = date.toLocaleDateString();
      const isSheetExist = await checkIsSheetExist(file.id, sheetName);
      if (!isSheetExist) {
        await addSheet(file.id, date.toLocaleDateString());
        await updateSheet(file.id, [PENDING_ORDER_TITLES], sheetName);
      }
      const formattedOrders = getFormattedOrder(order);
      const result = await appendRowInSheet(
        file.id,
        [formattedOrders],
        sheetName
      );
      resolve(file);
    } catch (ex) {
      reject(ex);
    }
  });
};

export const getOrders = (date) => {
  return new Promise(async (resolve, reject) => {
    try {
      await listPunPunFiles()
      const file = await createOrFindFile(
        ORDER_FILE_NAME,
        PENDING_ORDER_TITLES
      );
      const sheetName = date;
      const isSheetExist = await checkIsSheetExist(file.id, sheetName);
      const orderArray = [];
      if (isSheetExist) {
        const response = await getSheetData(file.id, sheetName);
        if (
          response &&
          response.result &&
          response.result.values &&
          response.result.values.length > 0
        ) {
          const data = response.result.values;
          const keys = data[0];
          data.splice(0, 1);
          data.forEach((item) => {
            const orderJson = {};
            keys.forEach((key, index) => {
              orderJson[key] = item[index];
            });
            orderArray.push(orderJson);
          });
        }
      }
      resolve(orderArray);
    } catch (ex) {
      reject(ex);
    }
  });
};
