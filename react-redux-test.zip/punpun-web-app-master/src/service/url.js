export const URLS = {
  GET_STORE_LIST: "https://d2m6sq2ge9.execute-api.ap-south-1.amazonaws.com/production/users/get-by-email",
  ADD_STORE: "https://d2m6sq2ge9.execute-api.ap-south-1.amazonaws.com/production/users"
}
