import { listFilesOfaFolder, moveFile } from './drive';

import {gapi} from 'gapi-script';

export function createSheet(title, folderId) {
  return new Promise(async (resolve, reject) => {
    try {
      let menuFile;
      try {
        const files = await listFilesOfaFolder(`'${folderId}' in parents`)
        console.log("create sheet files: ", files);
        if (files && files.length > 0) {
          menuFile = files.find(i => i.name === title && i.mimeType === "application/vnd.google-apps.spreadsheet")
        }
      } catch (ex) {
        console.log("create sheet Ex: ", ex);
      }
      if (menuFile) {
        resolve(menuFile);
        return;
      }
      gapi.client.sheets.spreadsheets.create({
        properties: {
          title: title
        }
      }).then(async (response) => {
        console.log("Create sheet response: ", response);
        const sheetId = response.result.spreadsheetId;
        await moveFile(sheetId, 'root', folderId)
        resolve({id: sheetId, name: title, mimeType: "application/vnd.google-apps.spreadsheet" });
      }).catch(reject);
    } catch(ex) {
      reject(ex);
    }
  })
}


export const updateSheet = (fileId, values, sheetName = "Sheet1") => {
  return new Promise((resolve, reject) => {
    if (fileId) {
      gapi.client.sheets.spreadsheets.values
        .update({
          spreadsheetId: fileId,
          range: `${sheetName}!A1:Z`,
          valueInputOption: 'RAW',
          resource: {range: `${sheetName}!A1:Z`, values},
        })
        .then((result, err) => {
          if (err) {
            reject(err);
          } else {
            resolve(result);
          }
        })
        .catch(reject);
    } else {
      reject('Invalid file id');
    }
  });
};


export const appendRowInSheet = (fileId, values, sheetName = "Sheet1") => {
  return new Promise((resolve, reject) => {
    if (fileId) {
      gapi.client.sheets.spreadsheets.values
        .append({
          spreadsheetId: fileId,
          range: `${sheetName}!A1:Z`,
          valueInputOption: 'RAW',
          resource: {range: `${sheetName}!A1:Z`, values},
        })
        .then((result, err) => {
          if (err) {
            reject(err);
          } else {
            resolve(result);
          }
        })
        .catch(reject);
    } else {
      reject('Invalid file id');
    }
  });
};



export const clearSheet = (fileId, sheetName = "Sheet1") => {
  return new Promise((resolve, reject) => {
    if (fileId) {
      gapi.client.sheets.spreadsheets.values
        .clear({
          spreadsheetId: fileId,
          range: `${sheetName}!A1:Z`,
        })
        .then((result, err) => {
          if (err) {
            reject(err);
          } else {
            resolve(result);
          }
        })
        .catch(reject);
    } else {
      reject('Invalid file id');
    }
  });
};


export const addSheet = (fileId, sheetName) => {
  return new Promise((resolve, reject) => {
    if (fileId) {
      gapi.client.sheets.spreadsheets.batchUpdate({
          spreadsheetId: fileId,
          resource: {
            requests: [
              {
                addSheet: {
                  properties: {
                    title: sheetName
                  }
                }
              }
            ]
          }
        })
        .then((result, err) => {
          if (err) {
            reject(err);
          } else {
            resolve(result);
          }
        })
        .catch(reject);
    } else {
      reject('Invalid file id');
    }
  });
};

export const checkIsSheetExist = (spreadsheetId, sheetName) => {
  return new Promise((resolve, reject) => {

    gapi.client.sheets.spreadsheets.values
    .get({
      spreadsheetId,
      range: `${sheetName}!A1:Z1`,
    }).then(res => {
      console.log("Check is sheet exist: ", res)
      resolve(true);
    }).catch(err => {
      console.log("Check is sheet err: ", err)
      resolve(false)})
  })
}


export const getSheetData = (fileId, sheet) => {
  return new Promise((resolve, reject) => {
    gapi.client.sheets.spreadsheets.values
          .get({
            spreadsheetId: fileId,
            range: `${sheet}!A1:Z`,
          }).then((result) => {
            resolve(result)
          }).catch(error => {
            reject(error)
          })
  })
}