import {gapi} from 'gapi-script';
import store from '../../redux/store';
import {updateSheet} from './sheet';
import uuid from 'react-uuid'

let punpunFolder;
let punpunFiles;
let menuFileId;
let menu;

let folderUpdateListener;

const MAIN_FOLDER_NAME = 'PunPun5';


const getMainFolderName = () => {
  console.log("getMainFolderName: ", store.getState())
  const state = store.getState();
  if (state && state.store && state.store.current) {
    return `PunPun_${state.store.current.store_name}`
  } else {
    return "PunPun_test"
  }
}

/**
 * getPunPunFolder.
 */
const getPunPunFolder = () => {
  return new Promise((resolve, reject) => {
    const mainFolder = getMainFolderName();
    gapi.client.drive.files
      .list({
        pageSize: 10,
        fields: 'nextPageToken, files(id, name, mimeType)',
        q: `mimeType = 'application/vnd.google-apps.folder' and name = '${mainFolder}'`,
        spaces: 'drive',
      })
      .then(function (response) {
        const res = JSON.parse(response.body);
        console.log('Folder:', res);
        if (res && res.files && res.files.length > 0) {
          const folder = res.files[0].id;
          punpunFolder = folder;
          resolve(folder);
        } else {
          reject('Folder not found');
        }
      })
      .catch(reject);
  });
};

export const listPunPunFiles = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const files = await listFilesOfaFolder();
      punpunFiles = files;
      if (folderUpdateListener) {
        const menuFile = punpunFiles.find((f) => f.name === 'Menu');
        if (menuFile) {
          folderUpdateListener({ folderId: punpunFolder, menuFileId: menuFile.id })
        }
      }
      resolve(files);
    } catch (ex) {
      reject(ex);
    }
  });
};

export const listFilesOfaFolder = (
  searchTermV
) => {
  return new Promise(async (resolve, reject) => {
    let searchTerm = searchTermV
    if (!punpunFolder) {
      await getPunPunFolder();
    }
    if (!searchTerm)
      {searchTerm = `'${punpunFolder}' in parents`}
    gapi.client.drive.files
      .list({
        pageSize: 10,
        fields: 'nextPageToken, files(id, name, mimeType)',
        q: searchTerm,
        spaces: 'drive',
      })
      .then(function (response) {
        const res = JSON.parse(response.body);
        console.log('Files:', res);
        if (res && res.files && res.files.length > 0) {
          resolve(res.files);
        } else {
          reject('Files not available');
        }
      })
      .catch(reject);
  });
};

export const fetchMenu = () => {
  return new Promise((resolve, reject) => {
    if (punpunFiles && punpunFiles.length > 0) {
      const menuFile = punpunFiles.find((f) => f.name === 'Menu');
      if (menuFile) {
        const fileId = menuFile.id;
        menuFileId = fileId;
        gapi.client.sheets.spreadsheets.values
          .get({
            spreadsheetId: fileId,
            range: 'Sheet1!A1:Z',
          })
          .then(function (response) {
            if (
              response &&
              response.result &&
              response.result.values &&
              response.result.values.length > 0
            ) {
              const data = response.result.values;
              const keys = data[0];
              data.splice(0, 1);
              console.log('Data: ', data);
              const menuArray = [];
              data.forEach((item) => {
                const menuJson = {};
                keys.forEach((key, index) => {
                  menuJson[key] = item[index];
                });
                menuArray.push(menuJson);
              });
              menu = menuArray;
              resolve(menuArray);
              return;
            }
            reject('Menu items not found');
            return;
          })
          .catch((err) => {
            reject(err);
            return;
          });
      } else {
        reject('Menu file not found');
      }
    } else {
      reject('Menu file not found');
    }
  });
};

export const setupMenuFile = () => {
  return new Promise(async (resolve, reject) => {
    try {
      await getPunPunFolder();
      await listPunPunFiles();
      let menu = await fetchMenu();
      let isSetFileId = false;
      isSetFileId = menu.some((item) => {
        return !item.fileId || item.fileId.trim() === '';
      });
      if (isSetFileId) {
        menu = await updateMenuWithFileId(menuFileId, menu);
      }
      resolve(menu);
    } catch (ex) {
      reject(ex);
    }
  });
};


export const initialSetup = (listener) => {
  folderUpdateListener = listener
  return new Promise(async (resolve, reject) => {
    try {
      let folderId;
      let menuFileId;
      try {
        folderId = await getPunPunFolder();
        const files = await listPunPunFiles();
        const menuFile = files.find((f) => f.name === 'Menu');
        menuFileId = menuFile.id;
      } catch(ex) {

      }
      resolve({ folderId, menuFileId });
    } catch (ex) {
      reject(ex);
    }
  });
};

const updateMenuWithFileId = (fileId, menu, files) => {
  return new Promise(async (resolve, reject) => {
    try {
      console.log('update menu');
      const values = [];
      const updatedMenu = [];
      menu.forEach((item, index) => {
        const filename = (item.Photo || item.Name).split('.')[0].toLowerCase();
        let fileId = '';
        const file = (files || punpunFiles).find(
          (item) => item.name.split('.')[0].toLowerCase() === filename
        );
        if (file && file.id) {
          fileId = file.id;
        }
        let id = item.id;
        if (!id) {
          id = uuid()
        }

        const updatedItem = {...item, id, fileId};
        if (index === 0) {
          const keys = Object.keys(updatedItem);
          values.push(keys);
        }
        updatedMenu.push(updatedItem);
        values.push(Object.values(updatedItem));
      });
      console.log("Update Menu: ", values);
      const result = await updateSheet(fileId, values);
      resolve(updatedMenu);
    } catch (ex) {
      reject(ex);
    }
  });
};

export const moveFile = (fileId, sourceFolderId, destinationFolderId) => {
  const move = {
    addParents: [destinationFolderId],
    removeParents: sourceFolderId,
    fileId,
  };
  console.log('MoveFile: ', move);
  return gapi.client.drive.files.update(move);
};

export const getMainFolderId = () => {
  return punpunFolder;
};

export const getGoogleFile = ({fileName, mimeType}) => {
  return punpunFiles.find(
    (i) => i.name === fileName && i.mimeType === mimeType
  );
};

export const createFolder = ({parentId, folderName}) => {
  return new Promise((resolve, reject) => {
    const fileMetadata = {
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
      parents: [parentId],
    };
    gapi.client.drive.files
      .create({
        resource: fileMetadata,
      })
      .then(function (response) {
        console.log('create folder response: ', response);
        resolve(response);
      })
      .catch(reject);
  });
};

export const createOrFindMainFolder = () => {
  return new Promise(async (resolve, reject) => {
    try {
      let folder;
      try {
        folder = await getPunPunFolder();
      } catch (ex) {
        const result = await createFolder({
          parentId: 'root',
          folderName: getMainFolderName(),
        });
        folder = result.result.id;
        punpunFolder = folder;
      }
      resolve(folder);
    } catch (ex) {
      reject(ex);
    }
  });
};

const deleteFile = (fileId) => {
  return new Promise((resolve, reject) => {
    const accessToken = gapi.auth.getToken().access_token;
    fetch(
      `https://www.googleapis.com/drive/v3/files/${fileId}`,
      {
        method: 'DELETE',
        headers: new Headers({Authorization: 'Bearer ' + accessToken}),
      }
    )
      .then(resolve)
      .catch(reject);
  })
}

export const uploadFile = (file, fileName) => {
  return new Promise(async (resolve, reject) => {
    const name = fileName || file.name

    const fileExist = punpunFiles.find(
      (f) => f.name === name && f.mimeType === file.type
    );
    if (fileExist) {
      try {
        await deleteFile(fileExist.id)
      } catch(ex) {
        // reject(ex)
      }
      // resolve(fileExist);
      // return;
    }

    const metadata = {
      name: name,
      mimeType: file.type,
      parents: [punpunFolder],
    };

    const accessToken = gapi.auth.getToken().access_token;
    const form = new FormData();
    form.append(
      'metadata',
      new Blob([JSON.stringify(metadata)], {type: 'application/json'})
    );
    form.append('file', file, name);

    fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id',
      {
        method: 'POST',
        headers: new Headers({Authorization: 'Bearer ' + accessToken}),
        body: form,
      }
    )
      .then((res) => {
        return res.json();
      })
      .then(function (val) {
        console.log(val);
        resolve(val);
      })
      .catch(reject);
  });
};

export const uploadMultipleMenuImagesFiles = (files, names) => {
  const arr = files.map((file, index) => uploadFile(file, names && names.length > index ? names[index] : undefined));
  let menuP = new Promise(async (resolve, reject) => {
    try {
      const uploaded = await Promise.all(arr);
      const p1 = await listPunPunFiles();
      const menu = await fetchMenu();
      const update = await updateMenuWithFileId(menuFileId, menu, p1);
      resolve(update)
    } catch(ex) {
      reject(ex)
    } 
  })
  

  return menuP;
};
