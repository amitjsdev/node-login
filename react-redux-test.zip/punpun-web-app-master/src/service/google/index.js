import {gapi} from 'gapi-script';
import { resetReducer } from '../../redux/actions';
import {setupMenuFile} from './drive'
import store from '../../redux/reducers/store';
// Array of API discovery doc URLs for APIs
const DISCOVERY_DOCS = [
  'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest',
  'https://sheets.googleapis.com/$discovery/rest?version=v4',
];

// Authorization scopes required by the API; multiple scopes can be
// included, separated by spaces.
const SCOPES =
  'https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/spreadsheets';


/**
 *  Initializes the API client library and sets up sign-in state
 *  listeners.
 */


 let signInListener;

const initClient = () => {
  console.log("Init client");
  gapi.client
    .init({
      apiKey: process.env.REACT_APP_GOOGLE_DRIVE_API_KEY,
      clientId: process.env.REACT_APP_SITE_ENVIRONMENT === "PROD" ? process.env.REACT_APP_GOOGLE_DRIVE_CLIENT_PROD_ID : process.env.REACT_APP_GOOGLE_DRIVE_CLIENT_DEV_ID,
      discoveryDocs: DISCOVERY_DOCS,
      scope: SCOPES,
    })
    .then(
      function () {
        console.log("Init client success");
        // Listen for sign-in state changes.
        gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);

        // Handle the initial sign-in state.
        updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
      },
      function (error) {
        console.log("Init client error: ", error);
      }
    );
};

/**
 *  Sign in the user upon button click.
 */
export const signInWithGoogle = (event) => {
  gapi.auth2.getAuthInstance().signIn();
};

/**
 *  Sign in the user upon button click.
 */
export const signOut = (event) => {
  gapi.auth2.getAuthInstance().signOut();
};


/**
 *  Called when the signed in status changes, to update the UI
 *  appropriately. After a sign-in, the API is called.
 */
const updateSigninStatus = (isSignedIn) => {
  console.log("updateSigninStatus: ", isSignedIn);
  if (isSignedIn) {
    // Set the signed in user

    const profile = gapi.auth2.getAuthInstance().currentUser.get().getBasicProfile();
    const id = profile.getId()
    const name = profile.getName()
    const image = profile.getImageUrl()
    const email = profile.getEmail()
    const user = { id, name, image, email };
    console.log(
      'updateSigninStatus user: ',
      user
    );


    // setupMenuFile()
      if (signInListener) {
        const accessToken = gapi.auth.getToken().access_token;
        signInListener(user, accessToken)
      }


  } else {
    // prompt user to sign in
    if (signInListener) {
      signInListener(null)
    }
    // handleAuthClick();
  }
};

const setSignInListener = (listener) => {
  signInListener = listener;
}

const initializeClient = (listener) => {
  setSignInListener(listener)
  gapi.load('client:auth2', initClient);
};

export default initializeClient;