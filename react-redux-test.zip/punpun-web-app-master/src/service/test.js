/* If the button appears to do nothing. make sure you are not blocking the authentication popups*/


// Enter a client ID for a web application from the Google Developer Console.
// In your Developer Console project, add a JavaScript origin that corresponds to the domain
// where you will be running the script.
var clientId = '131211991594-2l4cskeuaoa2o5m0jqdh0p79uksishnl.apps.googleusercontent.com';


625870332974-dhus3o9k7hibuh7013erg9m6nfunc2s8.apps.googleusercontent.com


// Enter the API key from the Google Develoepr Console - to handle any unauthenticated
// requests in the code.

// To use in your own application, replace this API key with your own.
var apiKey = 'AIzaSyDm_hXiAoCjmg01rTc6aPSuMcZWOF8EgqU';
AIzaSyDlp9iVH6NynQiYvNCTNWkXw2G8-Y2B5-g
// To enter one or more authentication scopes, refer to the documentation for the API.
var scopes = 'https://www.googleapis.com/auth/drive';

// Use a button to handle authentication the first time.
function handleClientLoad() {
  gapi.client.setApiKey(apiKey);
}

function checkAuth() {
  gapi.auth.authorize({client_id: clientId, scope: scopes, immediate: true}, handleAuthResult);
}


function handleAuthResult(authResult) {
  if (authResult && !authResult.error) {
    makeApiCall();
  } else {
   $('#auth-button').show();
    // could show a message here.
  }
}

function handleAuthClick() {
  gapi.auth.authorize({client_id: clientId, scope: scopes, immediate: false}, handleAuthResult);
  return false;
}

// Load the API and make an API call.  Display the results on the screen.
function makeApiCall() {  
    gapi.client.load('drive', 'v2', makeRequest);   
}

function makeRequest(){
  $('#drive-result').html('');
  // Make the Request, i only want documents so set the mime types on the q param.
  var request = gapi.client.request({
      'path': '/drive/v2/files?q=trashed=false ' +
              'and ( '+
                'mimeType contains "application/rtf" or ' +
                'mimeType contains "application/pdf" or ' +
                'mimeType contains "application/vnd.openxmlformats-officedocument.wordprocessingml.document" or ' +
                'mimeType contains "application/msword" ' +
              ')',
      'method': 'GET',
      'params': {'maxResults': '50'}
      });

  request.execute(function(resp) {  
    for (i=0; i<resp.items.length; i++) {
      var docTitle      = resp.items[i].title;
      var docModDate    = resp.items[i].modifiedDate;
      var userUpd       = resp.items[i].lastModifyingUserName;
      var userEmbed     = resp.items[i].embedLink;
      var userAltLink   = resp.items[i].alternateLink;
      var userdownloadUrl = resp.items[i].downloadUrl;
      var docFileSize   = resp.items[i].fileSize;
      var docID         = resp.items[i].id;
      var docType       = resp.items[i].mimeType;
      var docIco        = resp.items[i].iconLink;
    

      var fileInfo = document.createElement('li');

      // suggest using a template engine to make the below easier to manage
      $(fileInfo).append(
        '<input type="radio" id="' + docID + '" class="docOption" name="docOption" value="' + userdownloadUrl + '" />' +
        '<span class="icon"><img src="' + docIco + '" /></span>' +
        '<label for="' + docID + '">' + docTitle + '</label>'
      );
      
      document.getElementById('drive-result').appendChild(fileInfo);
    }
    
    $('#btn_save').show();
  }); 
  
}

function saveSelectedFile(){
  var selectedFile = $('.docOption:checked').val();
  alert('start the download of: ' + selectedFile);
}









function zipping(fileId) {
  var blobs = [];
  var mimeInf = [];
  fileId.forEach(function(e) {
      try {
          var file = DriveApp.getFileById(e);
          var mime = file.getMimeType();
          var name = file.getName();
      } catch (e) {
          return e
      }
      Logger.log(mime)
      var blob;
      if (mime.indexOf('google-apps') > 0) {
          mimeInf =
              mime == "application/vnd.google-apps.spreadsheet" ? ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", name + ".xlsx"] : mime == "application/vnd.google-apps.document" ? ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", name + ".docx"] : mime == "application/vnd.google-apps.presentation" ? ["application/vnd.openxmlformats-officedocument.presentationml.presentation", name + ".pptx"] : ["application/pdf", name + ".pdf"];
          blob = UrlFetchApp.fetch("https://www.googleapis.com/drive/v3/files/" + e + "/export?mimeType=" + mimeInf[0], {
              method: "GET",
              headers: { "Authorization": "Bearer " + ScriptApp.getOAuthToken() },
              muteHttpExceptions: true
          }).getBlob().setName(mimeInf[1]);
      } else {
          blob = UrlFetchApp.fetch("https://www.googleapis.com/drive/v3/files/" + e + "?alt=media", {
              method: "GET",
              headers: { "Authorization": "Bearer " + ScriptApp.getOAuthToken() },
              muteHttpExceptions: true
          }).getBlob().setName(name);
      }
      blobs.push(blob);
  });
  var zip = Utilities.zip(blobs, Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd_HHmmss") + '.zip');
  var bytedat = DriveApp.createFile(zip).getBlob().getBytes();
  return Utilities.base64Encode(bytedat);
}