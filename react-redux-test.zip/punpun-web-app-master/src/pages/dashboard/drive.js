import React, { useContext, useEffect, useState } from "react";
import handleClientLoad, { signOut } from "../../service/google";
import { punchCurrentOrderRequest, punchItem } from "../../redux/actions/order";

import { connect } from "react-redux";
import { gapi } from 'gapi-script';
import { getMenuRequest } from "../../redux/actions";

function Drive(props) {
  const [menu, setMenu] = useState([]);
  const [imgSrc, setImgSrc] = useState("");
  useEffect(() => {
console.log("drive props: ", props)
props.getMenu()
  }, [])

  const exportFile = async (fileId, mimeType, name) => {
    // gapi.client.drive.files

    // readAndUpdateSheet(fileId);
    // return

    const accessToken = gapi.auth.getToken().access_token;
    console.log("accessToken:", accessToken );
    const blob = fetch("https://www.googleapis.com/drive/v3/files/" + fileId + "?alt=media", {
                method: "GET",
                headers: { "Authorization": "Bearer " + accessToken },
                muteHttpExceptions: true
            }).then(response => response.blob())
            .then(images => {
                // Then create a local URL for that image and print it 
                const outside = URL.createObjectURL(images)
                console.log("outside: ", outside)
                setImgSrc(outside);
                // const reader = new FileReader();
                // reader.readAsDataURL(images); 
                // reader.onloadend = function() {
                //  const base64data = reader.result;                
                //     console.log(base64data);
                // }
            })

    //         console.log("blob: ", blob);
    return;
  

//     const accessToken = gapi.auth.getToken().access_token;
//     var xhr = new XMLHttpRequest();
// xhr.open("GET", "https://www.googleapis.com/drive/v3/files/"+fileId+'?alt=media', true);
// xhr.setRequestHeader('Authorization','Bearer '+accessToken);
// xhr.responseType = 'arraybuffer'
// xhr.onload = function(){
//     //base64ArrayBuffer from https://gist.github.com/jonleighton/958841
//     // const base64 = 'data:image/png;base64,' + base64ArrayBuffer(xhr.response);
    
//     const reader = new FileReader();
//     reader.onloadend = function() {
//       console.log("Base64: ", reader.result)
//       // callback(reader.result);
//     }

//     //do something with the base64 image here

// }
// xhr.send();
    // if (user && user.)
    return;
  // downloadFileOptions.headers = Object.assign({
  //     "Authorization": `Bearer ${apiToken}`
  // }, downloadFileOptions.headers);


  };



  const { menuItems } = props;
  return (
    <div className="dashboard">
      <img style={{width: 100, height: 100}} src={`http://drive.google.com/uc?export=view&id=1Lin8wc6IihQxWGxuVDDnzWl1RH27VH_S`} />
      <img style={{width: 100, height: 100}} src={imgSrc} />
      <button onClick={handleClientLoad}>Client Load</button>
      <button onClick={signOut}>Sign Out</button>
      <div>
      {
        (!!menuItems && menuItems.length > 0 && menuItems.map(item => {
          return (<button key={item.Name} onClick={() => props.punchItem(item)}>{item.Name}</button>)
        }))
      }
      </div>
      <button onClick={props.punchCurrentOrder}>Punch Order</button>
    </div>
  );
}


const selector = state => {
  return {
    menuItems: state.menu.items
  };
};


const actions = (dispatch) => ({
  getMenu: () => dispatch(getMenuRequest()),
  punchItem: (item) => dispatch(punchItem(item)),
  punchCurrentOrder: () => dispatch(punchCurrentOrderRequest())
});

export default connect(selector, actions)(Drive);
