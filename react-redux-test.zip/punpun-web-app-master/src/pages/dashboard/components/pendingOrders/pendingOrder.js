import * as actionTypes from '../../../../redux/actions';

import React, {useCallback, useContext} from 'react';
import {
  completeOrderRequest,
  deleteOrderRequest,
  punchCurrentOrderRequest,
  updateOrderRequest
} from '../../../../redux/actions/order';

import Button from '@material-ui/core/Button';
import CancelIcon from '@material-ui/icons/Cancel';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import {Divider} from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemText from '@material-ui/core/ListItemText';
import {ModalContext} from '../../../../hoc/Layout';
import ReceiptPrint from '../../../shared/receiptPrint';
import {connect} from 'react-redux';
import { getStoreListRequest } from '../../../../redux/actions';
import {makeStyles} from '@material-ui/core/styles';
import ConfirmPopup from './confirmPopup';
const useStyles = makeStyles((theme) => ({
  //   root: {
  //     width: '100%',
  //     maxWidth: 360,
  //     backgroundColor: theme.palette.background.paper,
  //   },
  root1: {
    minWidth: 275,
  },
}));

function PendingOrder(props) {
  const {order} = props;
  const classes = useStyles();
  const context=useContext(ModalContext)
  const [open, setOpen] = React.useState(false);

  const handleConfirmOpen = () => {
    setOpen(true);
  };

  const handleConfirmClose = (type) => {
    setOpen(false);
    if(type==1){
      props.deleteOrder(order);
    }
  }; 
   const handleCompleteOrder = useCallback(
    (e) => {
      props.completeOrder({...order, paymentMode: e.target.id});
    },
    [order]
  );
  const handleDeleteOrder = useCallback(
    (e) => {
      props.deleteOrder({...order});
    },
    [order]
  );
  const handleUpdateOrder = useCallback(
    (e) => {
      props.deleteOrder({...order});
    },
    [order]
  );
  console.log("pending order", order);
  let totalPrice = 0;
  let totalServiceTax = 0;
  if (Array.isArray(order.items)) {
    order.items.forEach((item) => {
      totalPrice = totalPrice + item.Price * item.quantity;
      // totalServiceTax=totalServiceTax+parseInt(item.service_tax);
    });
  }
  return (
    <>
    <Card className={`${classes.root1} mt-4`}>
      <CardHeader
        action={
          <IconButton aria-label="cross">
            <CancelIcon
              style={{color: '#f50057'}}
              onClick={
              //   (e) =>{
              // //  props.deleteOrder(order);
              // }
                handleConfirmOpen
            }
            />
          </IconButton>
        }
        title={''}
        subheader={`${order.time}`}
        className={` m-0`}
      />
      <CardContent>
        <List>
          {Array.isArray(order.items) &&
            order.items.map((item, index) => {
              const labelId = `checkbox-list-secondary-label-${index}`;
              return (
                <ListItem key={index} button>
                  <ListItemText
                    id={labelId}
                    primary={`${item.quantity} x ${item.Name}`}
                  />
                  <ListItemSecondaryAction>
                    ₹{item.quantity * item.Price}
                  </ListItemSecondaryAction>
                </ListItem>
              );
            })}
          <Divider />

          <ListItem button>
            <ListItemText id="dddd" primary="Total Bill:" />
            <ListItemSecondaryAction>
              ₹{totalPrice + totalServiceTax}
            </ListItemSecondaryAction>
          </ListItem>
        </List>
      </CardContent>
      <CardActions>
        <br />
        <Button
          size="small"
          variant="contained"
          color="secondary"
          onClick={(e) => {
          
            // props.updateOrder(order)
            context.handleOpen(1, order);
            // context.handleActionType(1, order)
          }}
        >
          Edit
        </Button>
        <Button
          size="small"
          variant="contained"
          color="primary"
          onClick={(e) => {
            // props.completeOrder(order);
            // props.updateOrder(order)
            console.log("onClick pay: ", order)
            context.handleOpen(2, order);
            // context.handleActionType(2, order)
          }}
        >
          Pay
        </Button>
      </CardActions>
    </Card>
<ConfirmPopup  
open={open} 
handleClose={handleConfirmClose}
title="Pending Order" description="Are you sure you want to delete this order"  />
</>
  );
}

const actions = (dispatch) => ({
  completeOrder: (order) => dispatch(completeOrderRequest(order)),
  updateOrder: (order) => dispatch(updateOrderRequest(order)),
  deleteOrder: (order) => dispatch(deleteOrderRequest(order)),
  punchOrder: (order) => dispatch(punchCurrentOrderRequest(order)),
  getList: () => dispatch(getStoreListRequest()),
});

export default connect(null, actions)(PendingOrder);
