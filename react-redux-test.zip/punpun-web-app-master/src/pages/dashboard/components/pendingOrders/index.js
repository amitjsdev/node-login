import PendingOrder from "./pendingOrder";
import React from "react";
import { connect } from "react-redux";

function PendingOrders(props) {
  const { pendingOrders } = props;
  console.log("Pending Orders: ", pendingOrders)
  return (
    <div>
      {
        (!!pendingOrders && pendingOrders.length > 0 && pendingOrders.map((item,index) => {
          return (
            <PendingOrder key={item.id} order={item} arrayIndex={index} />
          )
        }))
      }
    </div>
  );
}


const selector = state => {
  return {
    pendingOrders: state.order.pendingOrders
  };
};


const actions = (dispatch) => ({
});

export default connect(selector, actions)(PendingOrders);
