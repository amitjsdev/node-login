import { Link, Redirect, Route, useHistory } from "react-router-dom";
import React, { useEffect, useState } from 'react';

import CartItem from './CartItem';
import {ModalContext} from '../../../../hoc/Layout'
import ScrollBarHoc from '../../../../hoc/ScrollBarHoc';

export default function Cart(props) {
  
    const context=React.useContext(ModalContext);

       const {items,handleClose,handleActionType}=props;
       console.log(items);
    return (
    
    
  <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div className="modal-content" >

      <div className="modal-header">
        <h5 className="modal-title" id="exampleModalLongTitle">Cart</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={e=>context.handleClose()}>
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <ScrollBarHoc height={window.screen.height-300}>

      <div className="modal-body">

    <CartItem order={props.order} items={items} handleClose={handleClose} handleActionType={handleActionType} />

      </div>
      </ScrollBarHoc>

      </div>
    </div>
    );
  }