import React, {useContext} from 'react';
import {
  completeOrderRequest,
  deleteCurrentItem,
  punchCurrentOrderRequest,
  punchItem,
} from '../../../../redux/actions/order';

import Button from '@material-ui/core/Button';
import CancelIcon from '@material-ui/icons/Cancel';
import IconButton from '@material-ui/core/IconButton';
import {ModalContext} from '../../../../hoc/Layout';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import {TextField} from '@material-ui/core';
import {connect} from 'react-redux';
import {makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});

function CartItem(props) {
  const classes = useStyles();
  const context = useContext(ModalContext);

  const {items} = props;
  const punchOrderInSheet = () => {
    props.punchCurrentOrder();
    context.handleClose();
  };
  let totalPrice = 0;
  let totalServiceTax = 0;
  if (Array.isArray(items)) {
    items.forEach((item) => {
      totalPrice = totalPrice + item.Price * item.quantity;
      // totalServiceTax=totalServiceTax+parseInt(item.service_tax);
    });
  }


  const handleUpdateQuantity = (item, quantity) => {
    console.log('quantity: ', quantity);
    if (quantity && !isNaN(quantity)) props.punchItem({...item, quantity});
  };

  return (
    <div className="row">
      <div className="col-md-12 text-center">
        <TableContainer component={Paper}>
          <Table className={classes.table} aria-label="a dense table">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell align="right">Price</TableCell>
                <TableCell align="right">Qty</TableCell>
                <TableCell align="right">Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {items.map((row) => {
                return (
                  <TableRow key={row.Name}>
                    <TableCell component="th" scope="row">
                      {row.Name}
                    </TableCell>
                    <TableCell align="right">₹{row.Price}</TableCell>
                    <TableCell align="right">
                    <TextField
                        className="form-control form-control-sm float-right"
                        label=""
                        margin="dense"
                        variant="outlined"
                        type="number"
                        value={row.quantity}
                        onChange={(e) =>
                          handleUpdateQuantity(row, e.target.value)
                        }
                        // required={true}
                        inputProps={{
                          autoComplete: 'off',
                        }}
                        style={{width: '100px'}}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <IconButton aria-label="cross">
                        <CancelIcon
                          style={{color: '#f50057'}}
                          onClick={(e) => {
                            props.deleteItem(row);
                          }}
                        />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </div>

      {items.length > 0 && (
        <div className="col-md-12 text-center mt-5">
          <TableContainer component={Paper}>
            <Table className={classes.table} aria-label="a dense table">
              <TableBody>
                <TableRow key="1">
                  <TableCell component="th" scope="row">
                    Sub Total
                  </TableCell>
                  <TableCell align="right">₹{totalPrice}</TableCell>
                </TableRow>

                <TableRow key="2">
                  <TableCell component="th" scope="row">
                    Tax
                  </TableCell>
                  <TableCell align="right">₹{totalServiceTax}</TableCell>
                </TableRow>

                <TableRow key="3">
                  <TableCell component="th" scope="row">
                    Grand Total
                  </TableCell>
                  <TableCell align="right">
                    ₹{totalPrice + totalServiceTax}
                  </TableCell>
                </TableRow>

                <TableRow key="4">
                  <TableCell component="th" scope="row">
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={(e) => context.handleActionType(2, props.order)}
                    >
                      Pay
                    </Button>
                  </TableCell>
                  <TableCell align="right">
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={punchOrderInSheet}
                    >
                      {props.order.id ? "Update the order" : "Start a new sale"}
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      )}
    </div>
  );
}

const actions = (dispatch) => ({
  punchCurrentOrder: () => dispatch(punchCurrentOrderRequest()),
  completeOrder: (order) => dispatch(completeOrderRequest(order)),
  punchItem: (item) => dispatch(punchItem(item)),
  deleteItem: (item) => dispatch(deleteCurrentItem(item)),
});

export default connect(null, actions)(CartItem);
