import * as actionTypes from '../../../../redux/actions';

import React, { useCallback, useContext, useEffect, useState } from "react";
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Image from "./image";
import Typography from '@material-ui/core/Typography';
import { connect } from "react-redux";
import { punchItem } from "../../../../redux/actions/order";

function Item(props) {

  const { item } = props;

  const handlePunchItem = useCallback(() => {
    console.log("Punch Iteme",item);
    props.punchItem(item);
  }, [item]);

  return (
    <div className="col-md-3 col-sm-4 col-xs-6 mb-3 text-center" key={item.Name} >
          <Card onClick={handlePunchItem}>
      <CardActionArea>
                
                    <Image fileId={item.fileId}  alt="" />
                    <CardContent className='py-2 px-1'>
          <Typography  variant="h6" >
          {item.Name}
          </Typography>
          <Typography  variant="h6" >
          ₹{item.Price}
          </Typography>
    </CardContent>
      </CardActionArea>
    </Card>
</div>
   
  );
}


const actions = (dispatch) => ({
  punchItem: (item) => dispatch(punchItem(item)),
});

export default connect(null, actions)(Item);
