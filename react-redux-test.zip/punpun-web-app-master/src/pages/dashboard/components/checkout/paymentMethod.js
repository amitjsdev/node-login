import './paymentMethod.css';

import React, {useCallback, useEffect, useState} from 'react';
import {
  completeOrderRequest,
  punchCurrentOrderRequest,
} from '../../../../redux/actions/order';

import AccountBalanceOutlinedIcon from '@material-ui/icons/AccountBalanceOutlined';
import MobileScreenShareOutlinedIcon from '@material-ui/icons/MobileScreenShareOutlined';
import {ModalContext} from '../../../../hoc/Layout';
import MoneyOutlinedIcon from '@material-ui/icons/MoneyOutlined';
import PaymentOutlinedIcon from '@material-ui/icons/PaymentOutlined';
import {connect} from 'react-redux';
import {makeStyles} from '@material-ui/core/styles';
import {useSnackbar} from 'notistack';

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});

function PaymentMothod(props) {
  const context = React.useContext(ModalContext);
  const {enqueueSnackbar} = useSnackbar();

  const {items} = props;
  const punchOrderInSheet = () => {
    props.punchCurrentOrder();
    enqueueSnackbar('Order Added in pending list Successfully', {
      variant: 'success',
      anchorOrigin: {
        vertical: 'top',
        horizontal: 'right',
      },
    });
    context.handleClose();
  };
  const handleCompleteOrder = useCallback(
    (mode) => {
      props.completeOrder({...props.order, paymentMode: mode});
      enqueueSnackbar('Order completed Successfully', {
        variant: 'success',
        anchorOrigin: {
          vertical: 'top',
          horizontal: 'right',
        },
      });
      context.handleClose();
    },
    [items]
  );

  let totalPrice = 0;
  let totalServiceTax = 0;
  if (Array.isArray(items)) {
    items.forEach((item) => {
      totalPrice = totalPrice + item.Price * item.quantity;
      // totalServiceTax=totalServiceTax+parseInt(item.service_tax);
    });
  }
  return (
    <div class="row">
      <div class="col-md-12 payment-option-box">
        <div
          className="col-md-12 text-center mt-3"
          style={{fontSize: '25px', fontWeight: 'bold'}}
        >
          Total Bill: ₹{totalPrice}
        </div>

        <div className="col-md-12 text-center payment-container">
          <div
            class="col-md-3 payment-box"
            id="cash"
            name="cash"
            onClick={() => handleCompleteOrder("cash")}
            style={{cursor: 'pointer'}}
          >
            <MoneyOutlinedIcon
              color="primary"
              style={{fontSize: 50}}
            ></MoneyOutlinedIcon>
            <div>
              <span>Cash</span>
            </div>
          </div>

          <div
            class="col-md-3 payment-box"
            id="card"
            name="card"
            onClick={() => handleCompleteOrder("card")}
            style={{cursor: 'pointer'}}
          >
            <PaymentOutlinedIcon
              color="primary"
              style={{fontSize: 50}}
            ></PaymentOutlinedIcon>
            <div>
              <span>Card</span>
            </div>
          </div>

          <div
            class="col-md-3 payment-box"
            id="paytm/upi"
            name="paytm/upi"
            onClick={() => handleCompleteOrder("paytm/upi")}
            style={{cursor: 'pointer'}}
          >
            <AccountBalanceOutlinedIcon
              color="primary"
              style={{fontSize: 50}}
            ></AccountBalanceOutlinedIcon>
            <div>
              <span>Paytm/UPI</span>
            </div>
          </div>

          <div
            class="col-md-3 payment-box"
            id="other"
            name="other"
            onClick={() => handleCompleteOrder("other")}
            style={{cursor: 'pointer'}}
          >
            <MobileScreenShareOutlinedIcon
              color="primary"
              style={{fontSize: 50}}
            ></MobileScreenShareOutlinedIcon>
            <div>
              <span>Others</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const actions = (dispatch) => ({
  punchCurrentOrder: () => dispatch(punchCurrentOrderRequest()),
  completeOrder: (order) => dispatch(completeOrderRequest(order)),
});

export default connect(null, actions)(PaymentMothod);
