import { Link, Redirect, Route, useHistory } from "react-router-dom";
import React, { useContext, useEffect, useState } from 'react';

import {ModalContext} from '../../../../hoc/Layout'
import PaymentMethod from './paymentMethod';
import ScrollBarHoc from '../../../../hoc/ScrollBarHoc';

export default function Checkout(props) {
   
       const {items,handleClose,handleActionType, order}=props;
       console.log(items);
      const context=useContext(ModalContext);
    return (
    
    
  <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div className="modal-content" >

      <div className="modal-header">
        <h5 className="modal-title" id="exampleModalLongTitle">Checkout</h5>
        <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={e=>context.handleClose()}>
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <ScrollBarHoc height={window.screen.height-300}>

      <div className="modal-body">

    <PaymentMethod items={items} order={order} />

      </div>
      </ScrollBarHoc>

      </div>
    </div>
    );
  }