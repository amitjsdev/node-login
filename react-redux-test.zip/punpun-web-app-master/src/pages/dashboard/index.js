import React, {useCallback, useEffect, useState} from "react";
import { useHistory, withRouter } from 'react-router-dom';

import Badge from '@material-ui/core/Badge';
import Button from '@material-ui/core/Button';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import ClearIcon from '@material-ui/icons/Clear';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import Layout from '../../hoc/Layout';
import Menu from './components/menu'
import {ModalContext} from '../../hoc/Layout';
import ScrollBarHoc from '../../hoc/ScrollBarHoc';
import SearchIcon from '@material-ui/icons/Search';
import { TextField } from '@material-ui/core';
import { connect } from "react-redux";

function Dashboard(props) {
  const [isSearchDish,setSearchDish]=useState(false);
  const [search,setSearch]=useState('');
  const [categoryName,setCategoryName]=useState('All');
  const [Categories,setCategtories]=useState([]);

  const changeFieldHandler=(e)=>{
    setSearch(e.target.value)
}
  const handleAnalytics = useCallback(() => {
    props.history.push("/analytics")
  })
  const {currentOrder,menuItems}=props;
  useEffect(()=>{
  let CategoryNames=[]
  menuItems.forEach(item=>{
   
    if(CategoryNames.find(element=>element==item.Category) ==undefined){
    CategoryNames.push(item.Category);
    }
  });
  if(CategoryNames.length>0){
    CategoryNames.unshift("All");
  }
  setCategtories(CategoryNames);
},[menuItems])
  const handleBtnClick=(e,name)=>{
    setCategoryName(name);
}
 console.log(Categories,menuItems);
  return (
    <Layout>
      <ModalContext.Consumer >
      {context => {
       return (<div className="row products">
            
            <div className="col-md-12 pt-3">
                <div className="row">
            <div className="col-md-3 float-right ">

            
                <h2 className="burger-burger">POS</h2>
                <hr className="burger-hr" />
            
            </div>
            <div className="col-md-6">
            {isSearchDish &&<TextField className="form-control form-control-sm float-right p-0 m-0" label="Search"           
                margin="dense"
                variant="outlined"
                 value={search}
                  onChange={e=>changeFieldHandler(e)}
                  autoFocus
                // required={true}
                inputProps={{
                    autoComplete: 'off'
                 }} /> }
                 </div>
            <div className="col-md-3 float ">
                <ul className="top-icons" style={{float:"left",padding:0}}>
                    <li>
                    {isSearchDish?<ClearIcon className="mr-2" style={{fontSize: "41px",
                    marginBottom: "0",padding: "2px"}} onClick={e=>{setSearchDish(false);setSearch('')}} />
                    :<SearchIcon className="mr-2" style={{fontSize: "41px",
                    marginBottom: "0",padding: "2px"}} onClick={e=>setSearchDish(true)} />}</li>
                    {/* <li><FileCopyIcon style={{fontSize: "41px",
                    marginBottom: "0",padding: "2px"}} /></li> */}
                     <li  style={{cursor:"pointer",marginLeft:"10px"}}>
                     <Badge badgeContent={currentOrder.items?.length} color="secondary">
{/* <ShoppingBasketIcon style={{fontSize: "41px",
                    marginBottom: "0",padding: "2px 2px",marginLeft:"10px"}} /> */}
                    <Button variant="contained" color="primary" onClick={e=>context.handleOpen(1, currentOrder)}>Cart</Button>
                    </Badge>
                    </li>
                    
                </ul>
                </div>
                </div>
            </div>
            {/* <div className="col-md-12 pt-4">
            <ButtonGroup  aria-label="outlined button group">
            {data.length>0 && data.map((element,index)=><Button key={index} color={category_id==element.category_id?`secondary`:`default`} onClick={e=>handleBtnClick(e,element.category_id)}>{element.category}</Button>)}
      </ButtonGroup>
      </div> */}
         <div className="col-md-12">
            <ButtonGroup  aria-label="outlined button group">
            {Categories.length>0 && Categories.map((name,index)=><Button key={index} color={categoryName==name?`secondary`:`default`} onClick={e=>handleBtnClick(e,name)}>{name}</Button>)} 
      </ButtonGroup>
      </div>
            <ScrollBarHoc height={window.screen.height-250}>

     <Menu searchKey={search} categoryName={categoryName} />
     </ScrollBarHoc>       
          </div>);}}
          </ModalContext.Consumer>
     </Layout>
  );
}
const selector = state => {
  return {
    currentOrder: state.order.currentOrder,
    menuItems: state.menu.items
  };
};

export default connect(selector,null)(withRouter(Dashboard));
