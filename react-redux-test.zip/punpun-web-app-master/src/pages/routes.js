import { BrowserRouter as Router, Switch } from "react-router-dom";

import AddStore from "./setup/addStore";
import Analytics from "./analytics";
import AuthRoutes from "../authRoute";
import Dashboard from "./dashboard";
import Login from "./login";
import PrivateRoutes from "../privateRoute";
import React from "react";
import Settings from "./settings";
import UploadImages from "./setup/uploadImages";
import UploadMenu from "./setup/uploadMenu";
import UserProvider from "../providers/userProvider";
import history from "../providers/history";

function Routes() {
  return (
    <UserProvider>
    <Router history={history}>
    <div className="App">
        <Switch>
          <AuthRoutes exact path="/" component={Login}/>
          <PrivateRoutes exact path="/dashboard" component={Dashboard} />
          <PrivateRoutes exact path="/analytics" component={Analytics} />
          <PrivateRoutes exact path="/uploadMenu" type="setup" component={UploadMenu} />
          <PrivateRoutes exact path="/uploadImages" component={UploadImages} />
          <PrivateRoutes exact path="/addStore" component={AddStore} />
          <PrivateRoutes exact path="/settings" component={Settings} />
        </Switch>
    </div>
    </Router>
    </UserProvider>
  );
}

export default Routes;