import React, {useCallback, useState} from 'react';

import {Button} from '@material-ui/core';
import {ExcelRenderer} from 'react-excel-renderer';
import {MENU_MANDATORY_FIELDS} from '../../../utils/constants';
import MenuImageLayout from '../../../hoc/MenuImageLayout';
import axios from 'axios';
import {compose} from 'redux';
import {connect} from 'react-redux';
import {createMenuFile} from '../../../service/functions/menu';
import {createOrFindMainFolder} from '../../../service/google/drive';
import {withRouter} from 'react-router-dom';

function hasSubArray(master, sub) {
  return sub.every(((i) => (v) => (i = master.indexOf(v, i) + 1))(0));
}

function validateUploadedMenu(menu) {
  if (menu.length > 0) {
    const title = menu[0];
    if (title.length > 0) {
      return hasSubArray(title, MENU_MANDATORY_FIELDS);
    }
  }
  return false;
}

function UploadMenu(props) {
  const [showFileName, setShowFileName] = useState('No File Selected');
  const [selectedFile, setSelectedFile] = useState(null);
  const onFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    if (event.target.files.length > 0) {
      setShowFileName(event.target.files[0].name);
    } else {
      setShowFileName('No File Selected');
    }
  };

  const onFileUpload = () => {
    //just pass the fileObj as parameter
    if (!selectedFile) {
      return;
    }
    ExcelRenderer(selectedFile, (err, resp) => {
      if (err) {
        console.log(err);
      } else {
        console.log('Excel File: ', resp);
        const menu = resp.rows;
        const isValid = validateUploadedMenu(menu);
        if (isValid) {
          createMenuFile(menu)
            .then((res) => {
              console.log('createMenuFile res: ', res);
              props.history.push('/uploadImages');
            })
            .catch((err) => {
              console.log('err: ', err);
            });
        }
        console.log('isValid: ', isValid);
      }
    });
  };

  const fileData = () => {
    if (selectedFile) {
      return (
        <div>
          <h2>File Details:</h2>

          <p>File Name: {selectedFile.name}</p>

          <p>File Type: {selectedFile.type}</p>

          <p>Last Modified: {selectedFile.lastModifiedDate.toDateString()}</p>
        </div>
      );
    } else {
      return (
        <div>
          <br />
          <h4>Choose before Pressing the Upload button</h4>
        </div>
      );
    }
  };

  const handleSampleFileDownload = useCallback(() => {
    const method = 'GET';

    const url =
      'https://punpun-assets.s3.ap-south-1.amazonaws.com/Sample_Menu.xlsx';
    axios
      .request({
        url,
        method,
        responseType: 'blob', //important
      })

      .then(({data}) => {
        const downloadUrl = window.URL.createObjectURL(new Blob([data]));

        const link = document.createElement('a');

        link.href = downloadUrl;

        link.setAttribute('download', 'sample_menu.xlsx'); //any other extension

        document.body.appendChild(link);

        link.click();

        link.remove();
      });
  });

  return (
    <MenuImageLayout>
      <div className="form-group">
        <h5>Menu For {props.currentStore?.store_name}</h5>
        <label for="file" className="sr-only">
          File
        </label>
        <div className="input-group">
          <input
            type="text"
            name="filename"
            className="form-control"
            placeholder={showFileName}
            readonly
          />
          <span className="input-group-btn">
            <Button
              className=" custom-file-uploader"
              variant="contained"
              color="secondary"
              onChange={onFileChange}
            >
              <input
                type="file"
                name="file"
                accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
              />
              Select file
            </Button>
          </span>
        </div>
      </div>
      <Button variant="contained" color="primary" onClick={onFileUpload}>
        Upload File
      </Button>
      <Button
        style={{float: 'right'}}
        variant="contained"
        color="secondary"
        onClick={handleSampleFileDownload}
      >
        Sample File
      </Button>
      {fileData()}
    </MenuImageLayout>
  );
}

const selector = (state) => {
  return {
    currentStore: state.store.current,
  };
};

export default compose(withRouter, connect(selector, null))(UploadMenu);
