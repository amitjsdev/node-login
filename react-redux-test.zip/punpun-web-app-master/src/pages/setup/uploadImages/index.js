import React, {useCallback, useState} from 'react';

import { Button } from '@material-ui/core';
import MenuImageLayout from '../../../hoc/MenuImageLayout';
import {uploadMultipleMenuImagesFiles} from '../../../service/google/drive';
import { withRouter } from 'react-router-dom';

function UploadImages(props) {
  const [showFileName,setShowFileName]=useState('No Image Selected');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const onFileChange = (event) => {
    console.log('event.target.files', event.target.files);
    setSelectedFiles([...event.target.files]);
    if(event.target.files.length>0){
      let fileNameArray=[];
      for(let i=0;i<event.target.files.length;i++){
        fileNameArray.push(event.target.files[i].name)
      }
      setShowFileName(fileNameArray.toString());
    }else{
      setShowFileName('No Image Selected');
    }
  };

  const onFileUpload = () => {
    //just pass the fileObj as parameter
    if (!selectedFiles || selectedFiles.length === 0) {
      return;
    }
    uploadMultipleMenuImagesFiles(selectedFiles)
      .then((res) => {
        console.log('upload: ', res)
        props.history.push("/dashboard");
      })
      .catch((e) => console.log('upload error: ', e));
  };

  const fileData = () => {
    if (selectedFiles && selectedFiles.length > 0) {
      return selectedFiles.map((selectedFile) => {
        return (
          <div>
            <h2>File Details:</h2>

            <p>File Name: {selectedFile.name}</p>

            <p>File Type: {selectedFile.type}</p>

            <p>Last Modified: {selectedFile.lastModifiedDate.toDateString()}</p>
          </div>
        );
      });
    } else {
      return (
        <div>
          <br />
          <h4>Choose before Pressing the Upload button</h4>
        </div>
      );
    }
  };

  return (
       
    <MenuImageLayout>

    <div className="form-group">
          <label for="file" className="sr-only">File</label>
          <div className="input-group">
            <input type="text" name="filename" className="form-control" placeholder={showFileName} readonly />
            <span className="input-group-btn">
              <Button className=" custom-file-uploader" variant="contained" color="secondary"
              onChange={onFileChange}>
                <input type="file" name="file"   
                       accept="image/x-png,image/jpeg"
                       multiple={true}
                      
        />
                Select Images
              </Button>
            </span>
          </div>
        </div>
        <Button variant="contained" color="primary"
             onClick={onFileUpload} >Upload Images</Button>
        <Button style={{float: "right"}} variant="contained" color="secondary"
             onClick={() => props.history.push("/dashboard")} >Skip</Button>
      {fileData()}
    	</MenuImageLayout>
  );
}

export default withRouter(UploadImages);
