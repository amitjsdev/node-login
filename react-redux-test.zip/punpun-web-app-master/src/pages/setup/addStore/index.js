import React, {useCallback, useState} from 'react';

import {Button} from '@material-ui/core';
import MenuImageLayout from '../../../hoc/MenuImageLayout';
import {addStoreRequest} from '../../../redux/actions';
import {compose} from 'redux';
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';

function AddStore(props) {
  const [showFileName, setShowFileName] = useState('No File Selected');
  const [selectedFile, setSelectedFile] = useState(null);
  const [storeName, setStoreName] = useState('');
  const [storeAddress, setStoreAddress] = useState('');
  const [gst, setGst] = useState('');

  const onFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    if (event.target.files.length > 0) {
      setShowFileName(event.target.files[0].name);
    } else {
      setShowFileName('No File Selected');
    }
  };

  const handleSubmit = useCallback(() => {
    if (storeName) {
      props
        .addStore({storeName, storeAddress, gst})
        .then((res) => {
          setTimeout(() => {
            props.history.push('/dashboard')
          }, 500)
        })
        .catch(console.log);
    }
  }, [selectedFile, storeName, storeAddress, gst]);

  const onFileUpload = () => {
    //just pass the fileObj as parameter
    if (!selectedFile) {
      return;
    }
    // ExcelRenderer(selectedFile, (err, resp) => {
    //   if (err) {
    //     console.log(err);
    //   } else {
    //     console.log('Excel File: ', resp);
    //     const menu = resp.rows;
    //     const isValid = validateUploadedMenu(menu);
    //     if (isValid) {
    //       createMenuFile(menu).then(res => {
    //         console.log("createMenuFile res: ", res)
    //         props.history.push("/uploadImages");
    //       }).catch(err => {
    //         console.log("err: ", err)
    //       })
    //     }
    //     console.log("isValid: ", isValid);
    //   }
    // });
  };

  const fileData = () => {
    if (selectedFile) {
      return (
        <div>
          <h2>File Details:</h2>

          <p>File Name: {selectedFile.name}</p>

          <p>File Type: {selectedFile.type}</p>

          <p>Last Modified: {selectedFile.lastModifiedDate.toDateString()}</p>
        </div>
      );
    } else {
      return (
        <div>
          <br />
          <h4>Choose before Pressing the Upload button</h4>
        </div>
      );
    }
  };

  return (
    <MenuImageLayout>
      <div className="form-group">
        <label for="file" className="sr-only">
          File
        </label>
        <div className="input-group">
          <input
            type="text"
            name="filename"
            className="form-control"
            placeholder={showFileName}
            readonly
          />
          <span className="input-group-btn">
            <Button
              className=" custom-file-uploader"
              variant="contained"
              color="secondary"
              onChange={onFileChange}
            >
              <input
                type="file"
                name="file"
                accept="image/*"
              />
              Select file
            </Button>
          </span>
        </div>
      </div>
      <div className="text-center">
      <Button variant="contained" color="primary" onClick={onFileUpload}>
        Upload Store Icon
      </Button>
     </div  >
      {fileData()}
      <input
        value={storeName}
        placeholder="Store Name"
        className="form-control mt-3"
        onChange={(e) => setStoreName(e.target.value)}
      />
      <input
        value={storeAddress}
        placeholder="Store Address"
        class="form-control mt-3"
        onChange={(e) => setStoreAddress(e.target.value)}
      />
      <input
        value={gst}
        placeholder="GST Number"
        class="form-control mt-3"
        onChange={(e) => setGst(e.target.value)}
      />
      <div className="text-center">
      <Button variant="contained" className="mt-3" color="primary" onClick={handleSubmit}>
        Submit
      </Button>
      </div>
    </MenuImageLayout>
  );
}

const actions = (dispatch) => ({
  addStore: (data) =>
    new Promise((resolve, reject) =>
      dispatch(addStoreRequest({...data, resolve, reject}))
    ),
});

export default compose(withRouter, connect(null, actions))(AddStore);
