import React, { useEffect } from "react";
import { punchCurrentOrderRequest, punchItem } from "../../../../redux/actions/order";

import Item  from './item';
import { connect } from "react-redux";
import { getMenuRequest } from "../../../../redux/actions";

function Menu(props) {
  useEffect(() => {
    console.log("drive props: ", props)
    props.getMenu()
  }, [])



  const { menuItems } = props;

  return (
 
        <div className="row p-2" style={{overflowY:'hidden',boxSizing:'border-box',width:"98%"}}>

      {
        (!!menuItems && menuItems.length > 0 && menuItems.map(item => {
          return (<Item key={item.Name} item={item} getMenu={props.getMenu} />)
        }))
      }
      </div>
      // <button onClick={props.punchCurrentOrder}>Punch Order</button>
  );
}


const selector = state => {
  return {
    menuItems: state.menu.items
  };
};


const actions = (dispatch) => ({
  getMenu: () => dispatch(getMenuRequest()),
  punchItem: (item) => dispatch(punchItem(item)),
  punchCurrentOrder: () => dispatch(punchCurrentOrderRequest())
});

export default connect(selector, actions)(Menu);
