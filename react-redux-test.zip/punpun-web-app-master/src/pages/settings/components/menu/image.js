import React, {useEffect, useState} from 'react';

import {gapi} from 'gapi-script';

function Image(props) {
  const [imgSrc, setImgSrc] = useState('');
  const {fileId} = props;
  useEffect(() => {
    if (!fileId) {
      return
    }
    // const accessToken = gapi.auth.getToken().access_token;
    // fetch(
    //   'https://www.googleapis.com/drive/v3/files/' + fileId + '?alt=media',
    //   {
    //     method: 'GET',
    //     headers: {Authorization: 'Bearer ' + accessToken},
    //     muteHttpExceptions: true,
    //   }
    // )
    //   .then((response) => response.blob())
    //   .then((images) => {
    //     const outside = URL.createObjectURL(images);
    //     console.log("Outside: ", outside);
    //     setImgSrc(outside);
    //   });
  }, [fileId]);

  return (
    <>
      {(!!imgSrc) ? <img style={{width: "100%", height: "145px"}} src={imgSrc} /> : (!!fileId && !props.src) ? <img style={{width: "100%", height: "145px"}} src={`http://drive.google.com/uc?export=view&id=${fileId}`} /> : <img style={{width: "100%", height:"145px"}} src={props.src} />}
    </>
  );
}

export default Image;
