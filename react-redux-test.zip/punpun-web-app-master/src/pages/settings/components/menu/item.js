import * as actionTypes from '../../../../redux/actions';

import React, {useCallback, useContext, useEffect, useRef, useState} from 'react';

import Button from '@material-ui/core/Button';
import CancelIcon from '@material-ui/icons/Cancel';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import CheckCircle from '@material-ui/icons/CheckCircle';
import { IconButton } from '@material-ui/core';
import Image from './image';
import Typography from '@material-ui/core/Typography';
import {connect} from 'react-redux';
import {punchItem} from '../../../../redux/actions/order';
import { uploadMultipleMenuImagesFiles } from '../../../../service/google/drive';

function Item(props) {
  const inputRef = useRef();
  const [selectedFile, setSelectedFile] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const {item}= props;
  const onFileChange = (event) => {
    if (!isLoading) {
      setSelectedFile(event.target.files[0]);
    }
  };
  const uploadFile = (event) => {
    setLoading(true)
    uploadMultipleMenuImagesFiles([selectedFile], [item.Name]).then(r => {
      setSelectedFile(null)
      inputRef.current.value = "";
      setLoading(false)
      props.getMenu();
    }).catch(e => {
      setLoading(false)
    })
  };

  return (
    <div
      className="col-md-3 col-sm-4 col-xs-6 mb-3 text-center"
      key={item.Name}
    >
      <Card>
        
        <span className="input-group-btn">
            <div
              className="custom-file-uploader"
              onChange={onFileChange}
            >
              <input
                type="file"
                name="file"
                accept="image/x-png,image/jpeg"
                ref={inputRef}
              />
              <Image src={selectedFile ? URL.createObjectURL(selectedFile) : null} fileId={item.fileId} alt="" />
              {!selectedFile ? "Click to upload" : isLoading ? "Uploading..." : ""}
            </div>
          </span>
          <CardContent className="py-2 px-1">
            {selectedFile && !isLoading && <span><IconButton aria-label="cross">
                        <CheckCircle
                          style={{color: '#50c878'}}
                          onClick={(e) => {
                            uploadFile()
                          }}
                        />
                      </IconButton><IconButton aria-label="cross">
                        <CancelIcon
                          style={{color: '#f50057'}}
                          onClick={(e) => {
                            setSelectedFile(null)
                            inputRef.current.value = "";
                          }}
                        />
                      </IconButton></span>}
            <Typography variant="h6">{item.Name}</Typography>
            <Typography variant="h6">₹{item.Price}</Typography>
          </CardContent>
        
      </Card>
    </div>
  );
}

const actions = (dispatch) => ({
  punchItem: (item) => dispatch(punchItem(item)),
});

export default connect(null, actions)(Item);
