import React, {useCallback, useState} from 'react';
import {useHistory, withRouter} from 'react-router-dom';

import Layout from '../../hoc/Layout';
import Menu from './components/menu';
import {ModalContext} from '../../hoc/Layout';
import ScrollBarHoc from '../../hoc/ScrollBarHoc';
import {connect} from 'react-redux';

function Settings(props) {
  const {currentOrder} = props;

  const history = useHistory();
  return (
    <Layout>
      <ModalContext.Consumer>
        {(context) => {
          return (
            <div className="row products">

              <div className="col-md-12 pt-2">
                <h2 className="burger-burger">Settings</h2>
                <hr className="burger-hr" />
              </div>
              <ScrollBarHoc height={window.screen.height - 250}>
                <Menu />
              </ScrollBarHoc>
            </div>
          );
        }}
      </ModalContext.Consumer>
    </Layout>
  );
}
const selector = (state) => {
  return {
    currentOrder: state.order.currentOrder,
  };
};

export default connect(selector, null)(withRouter(Settings));
