import React, {useRef, useState} from 'react';

import { useReactToPrint } from 'react-to-print';

class ReceiptComponent extends React.PureComponent {
  render() {
  const { order } = this.props;
  return (
    <div>
      <h3>Receipt</h3>
      {
        !!order && !!order.items && order.items.length > 0 && order.items.map(item => {
          return <p key={item.Name}>{item.Name}</p>
        })
      }
    </div>
  );
}}


function ReceiptPrint(props) {
  const { order } = props;
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
  return (
    <>
    <ReceiptComponent order={order}  ref={componentRef} />
    <button onClick={handlePrint}>Print</button>
    </>
  );
}

export default ReceiptPrint;
