import React,{useState,useEffect} from 'react';
import ReactApexChart from "react-apexcharts";

export default function PieChart(props){

      
      
        const[series,setSeries]=useState(props.quanityArray)
      
      const options={
        chart: {
          width: '100%',
          type: 'pie',
        },
        labels:props.itemName,
        // theme: {
        //   monochrome: {
        //     enabled: true
        //   }
        // },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -5
            }
          }
        },
        title: {
          text: ""
        },
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        }
      };
      return (
        

<ReactApexChart options={options} series={series} type="pie" width={380}  />

      );
}