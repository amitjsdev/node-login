import React from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { makeStyles,withStyles } from '@material-ui/core/styles';
import PieChart from './chart';
const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
  root: {
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);
const useStyles = makeStyles({
  table: {
    minWidth: 500,
  },
});
function TopItems(props) {
 const {analytics}=props;
 const classes = useStyles();
//  values
let quanityArray=[];
let itemName=[]
if(analytics !=null){
 analytics.items.forEach(element=>{
  itemName.push(element.name);
  quanityArray.push(element.quantity);
 })
}
  return (
      <>
  {!!analytics && (<>
    {analytics.items.length>0 && <div className="col-12 mt-2" style={{margin:'auto',width:"380px"}}>
      <PieChart itemName={itemName} quanityArray={quanityArray} />
     </div>}
    
          <div className="col-12 mt-2">
          <TableContainer component={Paper}>
            <Table className={classes.table} aria-label="customized table">
              <TableHead>
                <TableRow>
                  <StyledTableCell>Name</StyledTableCell>
                  <StyledTableCell align="right">Quanity</StyledTableCell>
                  <StyledTableCell align="right">Amount</StyledTableCell>
                
                 
                </TableRow>
              </TableHead>
              <TableBody>
                {analytics.items !=undefined && analytics.items.map((row) => (
                  <StyledTableRow key={row.name}>
                    <StyledTableCell component="th" scope="row">
                      {row.name}
                    </StyledTableCell>
                    <StyledTableCell align="right">{row.quantity}</StyledTableCell>
                    <StyledTableCell align="right">₹ {row.amount}</StyledTableCell>
                   
                   
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          </div>
          </>
  )}
      </>
  );
}

export default TopItems;
