import React from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import IconButton from '@material-ui/core/IconButton';

function AnalyticsList(props) {
 const {analytics,setModuleType}=props;

  return (
      <>
  {!!analytics && (
              <List
      component="nav"
    >
      <Divider /> 
  <ListItem button>
        <ListItemText primary="Revenue" secondary={analytics.revenue}  />
        <ListItemSecondaryAction>
                    <IconButton edge="end" aria-label="">
                      <ChevronRightIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
        </ListItem>
        <Divider />
        <ListItem  button>
        <ListItemText primary="Number of Orders" secondary={analytics.numberOfOrders}  />
        <ListItemSecondaryAction  >
                    <IconButton edge="end" aria-label="">
                      <ChevronRightIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
        </ListItem>
        <Divider />
        <ListItem  button>
        <ListItemText primary="Payment Method" secondary={analytics.paymentMode && analytics.paymentMode.length > 0 && <p>Most Used Payment Mode: {analytics.paymentMode[0].mode}</p>}  />
        <ListItemSecondaryAction>
                    <IconButton edge="end" aria-label="">
                      <ChevronRightIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
        </ListItem>
        <Divider />
        <ListItem onClick={e=>setModuleType(2)} button>
        <ListItemText primary="Top Products" secondary={analytics.items && analytics.items.length > 0 && <p>Top Item: {analytics.items[0].name}</p>}  />
        <ListItemSecondaryAction>
                    <IconButton edge="end" aria-label="">
                      <ChevronRightIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
        </ListItem>
        <Divider />
      
      </List>
  )}
      </>
  );
}

export default AnalyticsList;
