export const getAnalyticsFromOrders = (orders) => {
  let revenue = 0;
  let numberOfOrders = orders.length;
  let paymentMethods = {};
  let itemAnalysis = {};
  orders.forEach((order) => {
    const amount = Number(order['Total Amount']);
    revenue += amount;
    const payMethod = order['Payment Mode'];
    let payAnaly = {orders: 0, amount: 0, mode: payMethod};
    if (paymentMethods[payMethod]) {
      payAnaly = {...paymentMethods[payMethod]};
    }
    payAnaly.orders += 1;
    payAnaly.amount += amount;
    paymentMethods[payMethod] = payAnaly;

    const items = JSON.parse(order.Items);
    items.forEach((item) => {
      let itemAnaly = {quantity: 0, amount: 0, name: item.Name};
      if (itemAnalysis[item.Name]) {
        itemAnaly = {...itemAnalysis[item.Name]};
      }
      itemAnaly.quantity += Number(item.quantity);
      itemAnaly.amount += Number(item.quantity) * Number(item.Price);
      itemAnalysis[item.Name] = itemAnaly
    });
  });
  const modeArray = Object.values(paymentMethods).sort((a, b) => {
    if (a.amount < b.amount) {
      return 1;
    }
    if (a.amount > b.amount) {
      return -1;
    }
    return 0;
  });

  const itemArray = Object.values(itemAnalysis).sort((a, b) => {
    if (a.amount < b.amount) {
      return 1;
    }
    if (a.amount > b.amount) {
      return -1;
    }
    return 0;
  });

  return { items: itemArray, paymentMode: modeArray, revenue, numberOfOrders }
};
