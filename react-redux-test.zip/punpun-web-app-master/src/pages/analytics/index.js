import React, {useEffect, useState} from 'react';

import AnalyticsList from './analyticsList';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import DatePicker from 'react-date-picker';
import Layout from '../../hoc/Layout';
import TopItems from './topItems';
import { getAnalyticsFromOrders } from './utils';
import {getOrders} from '../../service/functions/order';

function Analytics(props) {
  const [selectedDate, onDateChange] = useState(new Date());
  const [analytics, setAnalytics] = useState(null);
  const [moduleType,setModuleType]=useState(1);
  useEffect(() => {
    setAnalytics(null);

    if(selectedDate!=null){
    getOrders(selectedDate.toLocaleDateString())
      .then((orderArr) => {
        
        setAnalytics(getAnalyticsFromOrders(orderArr))
      })
      .catch((e) => setAnalytics(null));
    }
  }, [selectedDate]);

  console.log("analytics: ", analytics)
  return (
    <Layout>
       <div class="row">
      <div className="col-md-12 pt-4">
      <h2 className="burger-burger">
      {moduleType !=1 && <ArrowBackIcon style={{fontSize:"50px"}} className={`mr-3`} onClick={e=>setModuleType(1)} /> }
      {moduleType==1 &&`Analytics`}
      {moduleType==2 &&`Top Products`}</h2>
      <hr className="burger-hr" />
     </div>
     <div className="col-md-12 text-center mb-4">     
      <DatePicker onChange={onDateChange}  value={selectedDate} />
      {moduleType==1 && <AnalyticsList analytics={analytics} setModuleType={setModuleType} />}
      {moduleType==2 &&<TopItems analytics={analytics} setModuleType={setModuleType} /> }
    </div>
    </div>
    </Layout>
  );
}

export default Analytics;
