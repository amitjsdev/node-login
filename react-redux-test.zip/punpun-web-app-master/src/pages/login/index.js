import React from "react";
import { signInWithGoogle } from "../../service/google";

export default function Login() {

  return (
   
      
	<div className="card login-form mx-auto d-flex align-items-center justify-content-center">
	<div className="card-body">
		<div className="card-title text-center"><img src="/images/logo-bottom.jpg" /></div>
		<div className="card-text">
    <div className="login-buttons">
        <img onClick={signInWithGoogle} src="/images/logingoogle.png" alt="google icon" className="py-5 w-100" style={{cursor:'pointer'}}/>
       
      </div>
		</div>
</div>
</div>
  );
}