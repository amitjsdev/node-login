import React, {createContext, useEffect, useState} from 'react';
import { getStoreListRequest, setUserRequest } from '../redux/actions';

import { connect } from 'react-redux';
import { initialSetup } from '../service/google/drive';
import initializeClient from '../service/google';

export const UserContext = createContext({user: null});
const UserProvider = (props) => {
  const [user, setuser] = useState(undefined);
  const [menuData, setMenuData] = useState(null);
  const [storeList, setStoreList] = useState(null);
  useEffect(() => {
    console.log("initializeClient");
    initializeClient(async (user, accessToken) => {

      console.log("user: ", user);

      if (!user) {
        setuser(null);
        // setMenuData({})
        props.setUser(null)
        return;
      }
      const {name, email} = user;
      setuser({
        name,
        email,
      });
      props.setUser({ name, email })
      try {
        props.getStoreList()
      } catch (ex) {
        console.log("Ex: ", ex);
      }
    });
  }, []);

  useEffect(async () => {
    const result = props.storeList;
    if (result && result.length > 0 && JSON.stringify(storeList) !== JSON.stringify(result)) {
      setStoreList(result);
      console.log("setttupppp");
      const v =await initialSetup((data) => {
        console.log("initialSetup setMenuData: ", data);
        setMenuData({...data});
      });
      setMenuData(v);
    } else {
      setStoreList(result);
    }
  }, [props.storeList])

  return (
    <UserContext.Provider value={{user, menuData, storeList}}>{props.children}</UserContext.Provider>
  );
};


const selector = state => {
  return {
    storeList: state.store.list
  };
};


const actions = (dispatch) => ({
  setUser: (user) => dispatch(setUserRequest(user)),
  getStoreList: () => new Promise((resolve, reject) => dispatch(getStoreListRequest({ resolve, reject })))
});

export default connect(selector, actions)(UserProvider);
